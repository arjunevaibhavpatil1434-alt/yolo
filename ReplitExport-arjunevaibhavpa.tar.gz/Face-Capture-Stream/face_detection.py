"""
Real-Time Face Detection using OpenCV
=====================================
Captures video from webcam, detects faces using Haar Cascade,
draws bounding boxes, saves face images, and logs to CSV.

Usage:
    python face_detection.py

Press 'q' to quit the application.
"""

import cv2
import csv
import os
import time
from datetime import datetime

# --- Configuration ---
FACES_DIR = "faces_data"
CSV_FILE = "data.csv"
SAVE_INTERVAL = 2.0        # Minimum seconds between saving the same face region
HAAR_CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"

# In-memory tracker: maps a face region key to the last save timestamp
_last_saved_times: dict[str, float] = {}

# Timestamp shown on screen when a face is saved
_save_message_until: float = 0.0
_save_message_text: str = ""


def start_camera(camera_index: int = 0) -> cv2.VideoCapture:
    """
    Open the webcam and return a VideoCapture object.
    Raises RuntimeError if the camera cannot be opened.

    Args:
        camera_index: Index of the camera to open (default 0 = built-in webcam).

    Returns:
        An opened cv2.VideoCapture instance.
    """
    cap = cv2.VideoCapture(camera_index)

    if not cap.isOpened():
        raise RuntimeError(
            f"Cannot open camera at index {camera_index}. "
            "Make sure a webcam is connected and accessible."
        )

    # Reduce buffer size for lower latency (real-time performance)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    print(f"Camera opened successfully (index={camera_index}).")
    return cap


def detect_faces(
    frame: cv2.typing.MatLike,
    cascade: cv2.CascadeClassifier,
    scale_factor: float = 1.1,
    min_neighbors: int = 5,
    min_size: tuple[int, int] = (60, 60),
) -> list[tuple[int, int, int, int]]:
    """
    Detect faces in a single frame using Haar Cascade.

    Args:
        frame:        The BGR camera frame.
        cascade:      A pre-loaded CascadeClassifier.
        scale_factor: How much the image is scaled between detection passes.
        min_neighbors: Minimum neighbour rectangles for a valid detection.
        min_size:     Minimum face size to detect (width, height).

    Returns:
        A list of (x, y, w, h) tuples for each detected face.
    """
    # Convert to grayscale — Haar works on luminance only
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Equalise histogram for better detection under varying lighting
    gray = cv2.equalizeHist(gray)

    faces = cascade.detectMultiScale(
        gray,
        scaleFactor=scale_factor,
        minNeighbors=min_neighbors,
        minSize=min_size,
        flags=cv2.CASCADE_SCALE_IMAGE,
    )

    if len(faces) == 0:
        return []

    return [(int(x), int(y), int(w), int(h)) for (x, y, w, h) in faces]


def save_face_data(
    frame: cv2.typing.MatLike,
    face: tuple[int, int, int, int],
    faces_dir: str = FACES_DIR,
    csv_file: str = CSV_FILE,
) -> str | None:
    """
    Crop and save a detected face image, then append a record to the CSV file.
    Uses a simple time-based duplicate guard: if the same face region was saved
    within SAVE_INTERVAL seconds, the function skips saving and returns None.

    Args:
        frame:     The full BGR camera frame.
        face:      Bounding box (x, y, w, h) of the face to save.
        faces_dir: Directory where face images are stored.
        csv_file:  Path to the CSV log file.

    Returns:
        The saved filename (basename only) on success, or None if skipped.
    """
    global _last_saved_times

    x, y, w, h = face
    region_key = f"{x // 30}_{y // 30}_{w // 30}_{h // 30}"  # coarse grid key

    now = time.monotonic()
    if now - _last_saved_times.get(region_key, 0) < SAVE_INTERVAL:
        return None  # Too soon — skip duplicate

    # Crop the face region
    face_img = frame[y : y + h, x : x + w]
    if face_img.size == 0:
        return None

    # Build a timestamp-based filename
    timestamp = datetime.now()
    filename = timestamp.strftime("face_%Y%m%d_%H%M%S_%f") + ".jpg"
    filepath = os.path.join(faces_dir, filename)

    # Ensure the output directory exists
    os.makedirs(faces_dir, exist_ok=True)

    # Save the face image
    success = cv2.imwrite(filepath, face_img)
    if not success:
        print(f"Warning: failed to write face image to {filepath}")
        return None

    # Append a row to the CSV log
    csv_exists = os.path.isfile(csv_file)
    with open(csv_file, "a", newline="") as f:
        writer = csv.writer(f)
        if not csv_exists:
            writer.writerow(["filename", "datetime"])
        writer.writerow([filename, timestamp.strftime("%Y-%m-%d %H:%M:%S.%f")])

    # Update the duplicate guard
    _last_saved_times[region_key] = now

    return filename


def _draw_ui(
    frame: cv2.typing.MatLike,
    faces: list[tuple[int, int, int, int]],
    save_message: str,
) -> None:
    """
    Draw bounding boxes, face count, and save notification onto the frame in-place.

    Args:
        frame:        The BGR frame to annotate.
        faces:        List of (x, y, w, h) face bounding boxes.
        save_message: Non-empty string to display if a face was recently saved.
    """
    for x, y, w, h in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(
            frame,
            "Face",
            (x, y - 8),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (0, 255, 0),
            1,
            cv2.LINE_AA,
        )

    # Face count overlay (top-left)
    count_label = f"Faces detected: {len(faces)}"
    cv2.putText(
        frame,
        count_label,
        (10, 28),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (255, 255, 0),
        2,
        cv2.LINE_AA,
    )

    # Save confirmation overlay (top-right area)
    if save_message:
        cv2.putText(
            frame,
            save_message,
            (10, 58),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0, 200, 255),
            2,
            cv2.LINE_AA,
        )

    # Quit hint (bottom-left)
    cv2.putText(
        frame,
        "Press 'q' to quit",
        (10, frame.shape[0] - 12),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        (200, 200, 200),
        1,
        cv2.LINE_AA,
    )


def main() -> None:
    """
    Main loop: open the camera, detect faces each frame, save images,
    draw UI overlays, and run until the user presses 'q'.
    """
    global _save_message_until, _save_message_text

    # Load the Haar Cascade classifier
    if not os.path.exists(HAAR_CASCADE_PATH):
        raise FileNotFoundError(
            f"Haar Cascade file not found: {HAAR_CASCADE_PATH}\n"
            "Ensure OpenCV is installed: pip install opencv-python"
        )
    cascade = cv2.CascadeClassifier(HAAR_CASCADE_PATH)

    # Open the webcam
    try:
        cap = start_camera(camera_index=0)
    except RuntimeError as exc:
        print(f"Error: {exc}")
        return

    print("Starting face detection. Press 'q' in the video window to quit.")

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("Warning: failed to read frame from camera. Retrying...")
                time.sleep(0.05)
                continue

            # Detect faces in the current frame
            faces = detect_faces(frame, cascade)

            # Attempt to save each detected face (duplicate guard inside)
            for face in faces:
                saved_filename = save_face_data(frame, face)
                if saved_filename:
                    _save_message_text = f"Saved: {saved_filename}"
                    _save_message_until = time.monotonic() + 2.0
                    print(f"  [{datetime.now().strftime('%H:%M:%S')}] {_save_message_text}")

            # Clear the save message after its display duration
            current_save_msg = (
                _save_message_text if time.monotonic() < _save_message_until else ""
            )

            # Annotate and display the frame
            _draw_ui(frame, faces, current_save_msg)
            cv2.imshow("Real-Time Face Detection", frame)

            # Check for 'q' keypress (waitKey returns -1 if no key, else ASCII code)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                print("Quit signal received. Stopping...")
                break

    except KeyboardInterrupt:
        print("\nInterrupted by user. Stopping...")
    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("Camera released. Goodbye.")


if __name__ == "__main__":
    main()
