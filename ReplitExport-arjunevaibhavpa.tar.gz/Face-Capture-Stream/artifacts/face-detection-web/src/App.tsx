import { useEffect, useRef, useState, useCallback } from "react";
import * as faceapi from "@vladmandic/face-api";

const MODEL_URL = "https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/";
const SAVE_COOLDOWN_MS = 3000;
const MATCH_THRESHOLD = 0.52;
const DETECT_INTERVAL_MS = 120; // run detection every 120ms (~8fps for heavy pipeline)

const COLOURS = [
  "#22c55e","#3b82f6","#f59e0b","#ec4899",
  "#8b5cf6","#06b6d4","#f97316","#14b8a6",
];

type AppState = "idle" | "loading" | "running" | "error";

interface KnownFace {
  id: number;
  descriptor: Float32Array;
  colour: string;
  label: string;
}

interface SavedFace {
  key: string;
  filename: string;
  datetime: string;
  dataUrl: string;
  label: string;
}

const pad = (n: number, d = 2) => String(n).padStart(d, "0");

function makeFilename() {
  const d = new Date();
  return `face_${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}_${pad(d.getMilliseconds(),3)}.jpg`;
}

export default function App() {
  const videoRef  = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const runningRef = useRef(false);          // guard: skip frame if prev still going
  const knownRef  = useRef<KnownFace[]>([]);
  const nextIdRef = useRef(1);
  const saveCoolRef = useRef<Record<number,number>>({});

  const [state, setState]       = useState<AppState>("idle");
  const [loadMsg, setLoadMsg]   = useState("");
  const [errMsg, setErrMsg]     = useState("");
  const [faceCount, setFaceCount] = useState(0);
  const [uniqueCount, setUniqueCount] = useState(0);
  const [saved, setSaved]       = useState<SavedFace[]>([]);
  const [toast, setToast]       = useState("");
  const [fps, setFps]           = useState(0);

  const fpsRef   = useRef({ frames: 0, last: Date.now() });

  // ── stop everything ──────────────────────────────────────────────────────
  const stop = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    knownRef.current = [];
    nextIdRef.current = 1;
    saveCoolRef.current = {};
    runningRef.current = false;
    setState("idle");
    setFaceCount(0);
    setUniqueCount(0);
    setFps(0);
    // clear canvas
    const cv = canvasRef.current;
    if (cv) cv.getContext("2d")?.clearRect(0, 0, cv.width, cv.height);
  }, []);

  // ── resolve identity via FaceNet descriptor ──────────────────────────────
  const resolveIdentity = (descriptor: Float32Array): KnownFace => {
    let best: KnownFace | null = null;
    let bestDist = Infinity;
    for (const k of knownRef.current) {
      const dist = faceapi.euclideanDistance(descriptor, k.descriptor);
      if (dist < bestDist) { bestDist = dist; best = k; }
    }
    if (best && bestDist < MATCH_THRESHOLD) {
      // running-average update so descriptor drifts with appearance
      for (let i = 0; i < descriptor.length; i++)
        best.descriptor[i] = best.descriptor[i] * 0.88 + descriptor[i] * 0.12;
      return best;
    }
    const id     = nextIdRef.current++;
    const colour = COLOURS[(id - 1) % COLOURS.length];
    const label  = `Person ${id}`;
    const entry: KnownFace = { id, descriptor: descriptor.slice(), colour, label };
    knownRef.current.push(entry);
    return entry;
  };

  // ── save a face crop ─────────────────────────────────────────────────────
  const saveFace = (video: HTMLVideoElement, box: faceapi.Box, identity: KnownFace) => {
    const now = Date.now();
    if ((now - (saveCoolRef.current[identity.id] ?? 0)) < SAVE_COOLDOWN_MS) return;
    saveCoolRef.current[identity.id] = now;

    const { x, y, width, height } = box;
    const off = document.createElement("canvas");
    off.width  = Math.max(1, Math.round(width));
    off.height = Math.max(1, Math.round(height));
    off.getContext("2d")!.drawImage(video, x, y, width, height, 0, 0, off.width, off.height);
    const dataUrl  = off.toDataURL("image/jpeg", 0.9);
    const filename = makeFilename();
    const key      = `${identity.id}-${filename}`;

    setSaved(prev => [
      { key, filename, datetime: new Date().toLocaleString(), dataUrl, label: identity.label },
      ...prev,
    ].slice(0, 30));
    setToast(`Saved: ${identity.label}`);
    setTimeout(() => setToast(""), 2000);
  };

  // ── one detection tick ───────────────────────────────────────────────────
  const tick = useCallback(async () => {
    if (runningRef.current) return;   // skip if previous frame is still processing
    const video  = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    if (video.paused || video.ended || video.readyState < 2) return;

    const vw = video.videoWidth;
    const vh = video.videoHeight;
    if (!vw || !vh) return;          // video not yet sized — skip this tick

    runningRef.current = true;
    try {
      // Keep canvas in sync with actual video pixel dimensions
      if (canvas.width !== vw || canvas.height !== vh) {
        canvas.width  = vw;
        canvas.height = vh;
      }

      const results = await faceapi
        .detectAllFaces(video, new faceapi.SsdMobilenetv1Options({ minConfidence: 0.45 }))
        .withFaceLandmarks()
        .withFaceDescriptors();

      setFaceCount(results.length);

      // FPS counter
      fpsRef.current.frames++;
      const now = Date.now();
      if (now - fpsRef.current.last >= 1000) {
        setFps(fpsRef.current.frames);
        fpsRef.current = { frames: 0, last: now };
      }

      const ctx = canvas.getContext("2d")!;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // scale detections from display size to actual video size
      const scaleX = vw / video.clientWidth  || 1;
      const scaleY = vh / video.clientHeight || 1;

      for (const det of results) {
        const identity = resolveIdentity(det.descriptor);

        // raw box in video pixel space
        const rb = det.detection.box;
        const bx = rb.x * scaleX;
        const by = rb.y * scaleY;
        const bw = rb.width  * scaleX;
        const bh = rb.height * scaleY;

        const score  = Math.round(det.detection.score * 100);
        const colour = identity.colour;

        // bounding box
        ctx.strokeStyle = colour;
        ctx.lineWidth   = 2.5;
        ctx.strokeRect(bx, by, bw, bh);

        // label pill
        const label = `${identity.label}  ${score}%`;
        ctx.font = "bold 13px sans-serif";
        const tw   = ctx.measureText(label).width + 18;
        const ph   = 22;
        ctx.fillStyle = colour;
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(bx, by - ph - 3, tw, ph, 4);
        else               ctx.rect(bx, by - ph - 3, tw, ph);
        ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.fillText(label, bx + 9, by - 8);

        // landmark dots (scaled)
        ctx.fillStyle = colour + "bb";
        for (const pt of det.landmarks.positions) {
          ctx.beginPath();
          ctx.arc(pt.x * scaleX, pt.y * scaleY, 1.6, 0, Math.PI * 2);
          ctx.fill();
        }

        saveFace(video, { x: rb.x, y: rb.y, width: rb.width, height: rb.height } as faceapi.Box, identity);
      }

      // HUD
      const hudText = `FaceNet · ${results.length} face${results.length!==1?"s":""}  |  ${fps} fps`;
      ctx.font = "bold 13px sans-serif";
      const hudW = ctx.measureText(hudText).width + 24;
      ctx.fillStyle = "rgba(0,0,0,0.60)";
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(8, 8, hudW, 34, 6);
      else               ctx.rect(8, 8, hudW, 34);
      ctx.fill();
      ctx.fillStyle = "#facc15";
      ctx.fillText(hudText, 20, 30);

      setUniqueCount(knownRef.current.length);
    } catch {
      // silent — just skip this frame; don't crash the loop
    } finally {
      runningRef.current = false;
    }
  }, [fps]);

  // ── start pipeline ───────────────────────────────────────────────────────
  const start = useCallback(async () => {
    try {
      setState("loading");
      setErrMsg("");

      setLoadMsg("Loading SSD MobileNet detector…");
      await faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL);

      setLoadMsg("Loading face landmark model…");
      await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);

      setLoadMsg("Loading FaceNet recognition model…");
      await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);

      setLoadMsg("Requesting camera access…");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: "user" },
      });
      streamRef.current = stream;

      const video = videoRef.current!;
      video.srcObject = stream;
      await new Promise<void>((res, rej) => {
        video.onloadedmetadata = () => res();
        video.onerror = rej;
      });
      await video.play();

      setState("running");
      // tick on a fixed interval — more predictable than rAF for heavy async work
      timerRef.current = setInterval(tick, DETECT_INTERVAL_MS);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (/Permission|NotAllowed|denied/i.test(msg))
        setErrMsg("Camera permission denied. Please allow access in your browser settings.");
      else if (/NotFound|DevicesNotFound/i.test(msg))
        setErrMsg("No camera detected. Please connect a webcam.");
      else
        setErrMsg(`Failed to start: ${msg}`);
      setState("error");
    }
  }, [tick]);

  useEffect(() => () => stop(), [stop]);

  const download = (face: SavedFace) => {
    const a = document.createElement("a");
    a.href = face.dataUrl;
    a.download = face.filename;
    a.click();
  };

  // ── Loading steps UI ─────────────────────────────────────────────────────
  const steps = [
    "Loading SSD MobileNet detector…",
    "Loading face landmark model…",
    "Loading FaceNet recognition model…",
    "Requesting camera access…",
  ];
  const stepIdx = steps.indexOf(loadMsg);

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col select-none">
      {/* Header */}
      <header className="px-5 py-3 border-b border-gray-800 flex items-center gap-3 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-green-600 flex items-center justify-center font-black text-sm">F</div>
        <div>
          <h1 className="font-bold text-base leading-none">Face Detection</h1>
          <p className="text-xs text-gray-500 mt-0.5">FaceNet · SSD MobileNet · 68 Landmarks</p>
        </div>
        {state === "running" && (
          <div className="ml-auto flex items-center gap-4 text-sm">
            <span className="text-gray-500">{fps} fps</span>
            <span className="flex items-center gap-1.5 text-green-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              Live
            </span>
          </div>
        )}
      </header>

      <main className="flex-1 flex flex-col lg:flex-row min-h-0">
        {/* ── Left: video ── */}
        <div className="flex-1 flex flex-col items-center justify-center gap-4 p-5">
          {/* Camera viewport */}
          <div className="relative w-full max-w-2xl rounded-xl overflow-hidden bg-gray-900 border border-gray-800"
               style={{ aspectRatio: "16/9" }}>

            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              muted playsInline
              style={{ display: state === "running" ? "block" : "none" }}
            />
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full pointer-events-none"
              style={{ display: state === "running" ? "block" : "none" }}
            />

            {/* Overlay for non-running states */}
            {state !== "running" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 px-8 text-center">
                <div className="text-6xl">📷</div>

                {state === "idle" && (
                  <p className="text-gray-400 text-sm max-w-xs">
                    Click <strong className="text-white">Start Camera</strong> to begin real-time
                    face detection with FaceNet identity tracking.
                  </p>
                )}

                {state === "loading" && (
                  <div className="w-full max-w-xs space-y-3">
                    {steps.map((step, i) => {
                      const done   = i < stepIdx;
                      const active = i === stepIdx;
                      return (
                        <div key={i} className="flex items-center gap-3">
                          <div className={[
                            "w-5 h-5 rounded-full shrink-0 flex items-center justify-center text-xs font-bold",
                            done   ? "bg-green-500 text-white" : "",
                            active ? "border-2 border-green-400 border-t-transparent animate-spin" : "",
                            !done && !active ? "bg-gray-800" : "",
                          ].join(" ")}>
                            {done ? "✓" : ""}
                          </div>
                          <span className={`text-sm ${done ? "text-green-400" : active ? "text-white" : "text-gray-600"}`}>
                            {step}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}

                {state === "error" && (
                  <>
                    <p className="text-red-400 text-sm max-w-xs">{errMsg}</p>
                    <button
                      onClick={start}
                      className="px-5 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm font-medium transition-colors"
                    >Try Again</button>
                  </>
                )}
              </div>
            )}

            {/* Save toast */}
            {toast && (
              <div className="absolute bottom-3 inset-x-3 bg-green-700/90 backdrop-blur text-white text-xs font-medium rounded-lg px-3 py-2 text-center">
                ✓ {toast}
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="flex gap-3">
            {state !== "running"
              ? <button
                  onClick={start}
                  disabled={state === "loading"}
                  className="px-7 py-2.5 bg-green-600 hover:bg-green-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg font-semibold text-sm transition-colors"
                >
                  {state === "loading" ? "Loading…" : "Start Camera"}
                </button>
              : <button
                  onClick={stop}
                  className="px-7 py-2.5 bg-red-600 hover:bg-red-500 rounded-lg font-semibold text-sm transition-colors"
                >
                  Stop Camera
                </button>
            }
          </div>

          {/* Stats */}
          {state === "running" && (
            <div className="flex gap-3 flex-wrap justify-center">
              {[
                { val: faceCount,   label: "Faces Detected",   color: "text-green-400"  },
                { val: uniqueCount, label: "Unique Identities", color: "text-blue-400"   },
                { val: saved.length,label: "Faces Saved",       color: "text-purple-400" },
              ].map(s => (
                <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-xl px-5 py-3 text-center min-w-[110px]">
                  <p className={`text-3xl font-bold ${s.color}`}>{s.val}</p>
                  <p className="text-xs text-gray-500 mt-1">{s.label}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── Right: saved faces sidebar ── */}
        <aside className="w-full lg:w-72 border-t lg:border-t-0 lg:border-l border-gray-800 flex flex-col shrink-0">
          <div className="px-4 py-3 border-b border-gray-800">
            <h2 className="font-semibold text-sm">Captured Faces</h2>
            <p className="text-xs text-gray-600 mt-0.5">Per-identity · click to download</p>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
            {saved.length === 0
              ? <p className="text-center text-gray-600 text-sm py-12">No faces captured yet.</p>
              : saved.map(face => (
                  <button
                    key={face.key}
                    onClick={() => download(face)}
                    className="w-full flex items-center gap-3 bg-gray-900 hover:bg-gray-800 border border-gray-800 rounded-lg p-2 text-left transition-colors group"
                  >
                    <img
                      src={face.dataUrl}
                      alt={face.label}
                      className="w-12 h-12 object-cover rounded-md bg-gray-800 shrink-0"
                    />
                    <div className="overflow-hidden min-w-0">
                      <p className="text-xs font-semibold text-gray-200">{face.label}</p>
                      <p className="text-xs text-gray-500 truncate">{face.filename}</p>
                      <p className="text-xs text-gray-600">{face.datetime}</p>
                    </div>
                    <span className="ml-auto text-gray-600 group-hover:text-gray-300 shrink-0 text-sm">↓</span>
                  </button>
                ))
            }
          </div>
        </aside>
      </main>
    </div>
  );
}
