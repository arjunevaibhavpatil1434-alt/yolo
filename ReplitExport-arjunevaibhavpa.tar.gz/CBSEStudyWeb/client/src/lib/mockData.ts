import type { Grade, Subject, Chapter } from "@shared/schema";

//todo: remove mock functionality
export const grades: Grade[] = [
  { id: 6, name: "Class 6", description: "Foundation concepts across all subjects" },
  { id: 7, name: "Class 7", description: "Building on fundamental knowledge" },
  { id: 8, name: "Class 8", description: "Advanced middle school curriculum" },
];

//todo: remove mock functionality
export const subjects: Subject[] = [
  {
    id: "math",
    name: "Mathematics",
    icon: "math",
    description: "Numbers, Algebra, Geometry",
    color: "blue",
  },
  {
    id: "science",
    name: "Science",
    icon: "science",
    description: "Physics, Chemistry, Biology",
    color: "green",
  },
  {
    id: "social",
    name: "Social Studies",
    icon: "social",
    description: "History, Geography, Civics",
    color: "amber",
  },
  {
    id: "english",
    name: "English",
    icon: "english",
    description: "Grammar, Literature, Writing",
    color: "purple",
  },
  {
    id: "hindi",
    name: "Hindi",
    icon: "hindi",
    description: "व्याकरण, साहित्य, लेखन",
    color: "orange",
  },
];

//todo: remove mock functionality
export const chaptersData: Record<string, Chapter[]> = {
  math: [
    {
      id: "math-1",
      number: 1,
      title: "Integers",
      lessons: [
        {
          id: "math-1-1",
          title: "Introduction to Integers",
          content: "Integers are whole numbers that can be positive, negative, or zero. They extend the number system beyond natural numbers.",
        },
        {
          id: "math-1-2",
          title: "Operations on Integers",
          content: "Learn how to add, subtract, multiply, and divide integers using number line and rules.",
        },
      ],
    },
    {
      id: "math-2",
      number: 2,
      title: "Fractions and Decimals",
      lessons: [
        {
          id: "math-2-1",
          title: "Understanding Fractions",
          content: "A fraction represents a part of a whole. It consists of a numerator and denominator.",
        },
        {
          id: "math-2-2",
          title: "Decimal Numbers",
          content: "Decimals are another way to represent fractions using the base-10 system.",
        },
      ],
    },
  ],
  science: [
    {
      id: "science-1",
      number: 1,
      title: "Nutrition in Plants",
      lessons: [
        {
          id: "science-1-1",
          title: "Photosynthesis",
          content: "Plants make their own food through photosynthesis using sunlight, water, and carbon dioxide.",
        },
        {
          id: "science-1-2",
          title: "Nutrients in Plants",
          content: "Plants require various nutrients like nitrogen, phosphorus, and potassium for growth.",
        },
      ],
    },
  ],
  social: [
    {
      id: "social-1",
      number: 1,
      title: "The Mughal Empire",
      lessons: [
        {
          id: "social-1-1",
          title: "Rise of the Mughals",
          content: "The Mughal Empire was founded by Babur in 1526 after the First Battle of Panipat.",
        },
      ],
    },
  ],
  english: [
    {
      id: "english-1",
      number: 1,
      title: "Parts of Speech",
      lessons: [
        {
          id: "english-1-1",
          title: "Nouns and Pronouns",
          content: "Nouns are naming words while pronouns replace nouns to avoid repetition.",
        },
      ],
    },
  ],
  hindi: [
    {
      id: "hindi-1",
      number: 1,
      title: "वर्ण और मात्राएं",
      lessons: [
        {
          id: "hindi-1-1",
          title: "स्वर और व्यंजन",
          content: "हिंदी वर्णमाला में स्वर और व्यंजन दो मुख्य भाग हैं।",
        },
      ],
    },
  ],
};
