import { ThemeProvider } from "../ThemeProvider";
import { SubjectCard } from "../SubjectCard";
import { subjects } from "@/lib/mockData";

export default function SubjectCardExample() {
  return (
    <ThemeProvider>
      <div className="p-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl">
        {subjects.slice(0, 3).map((subject) => (
          <SubjectCard
            key={subject.id}
            subject={subject}
            onClick={() => console.log(`Clicked ${subject.name}`)}
          />
        ))}
      </div>
    </ThemeProvider>
  );
}
