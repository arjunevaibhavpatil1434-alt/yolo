import { ThemeProvider } from "../ThemeProvider";
import { ChapterList } from "../ChapterList";
import { chaptersData } from "@/lib/mockData";

export default function ChapterListExample() {
  return (
    <ThemeProvider>
      <div className="p-8 max-w-4xl">
        <ChapterList
          chapters={chaptersData.math}
          onLessonClick={(chapterId, lessonId) =>
            console.log(`Clicked lesson: ${chapterId} - ${lessonId}`)
          }
        />
      </div>
    </ThemeProvider>
  );
}
