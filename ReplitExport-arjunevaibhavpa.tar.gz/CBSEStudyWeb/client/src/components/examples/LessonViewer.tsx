import { ThemeProvider } from "../ThemeProvider";
import { LessonViewer } from "../LessonViewer";
import { chaptersData } from "@/lib/mockData";

export default function LessonViewerExample() {
  const chapter = chaptersData.math[0];
  const lesson = chapter.lessons[0];

  return (
    <ThemeProvider>
      <div className="p-8">
        <LessonViewer
          lesson={lesson}
          chapterTitle={chapter.title}
          chapterNumber={chapter.number}
        />
      </div>
    </ThemeProvider>
  );
}
