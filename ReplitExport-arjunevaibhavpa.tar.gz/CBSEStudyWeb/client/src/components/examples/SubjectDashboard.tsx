import { ThemeProvider } from "../ThemeProvider";
import { SubjectDashboard } from "../SubjectDashboard";
import { subjects } from "@/lib/mockData";

export default function SubjectDashboardExample() {
  return (
    <ThemeProvider>
      <SubjectDashboard
        grade={7}
        subjects={subjects}
        onSubjectClick={(id) => console.log(`Clicked subject: ${id}`)}
      />
    </ThemeProvider>
  );
}
