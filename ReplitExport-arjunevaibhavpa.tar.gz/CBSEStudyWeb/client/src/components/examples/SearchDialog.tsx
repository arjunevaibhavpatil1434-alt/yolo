import { useState } from "react";
import { ThemeProvider } from "../ThemeProvider";
import { SearchDialog } from "../SearchDialog";
import { Button } from "@/components/ui/button";

export default function SearchDialogExample() {
  const [open, setOpen] = useState(false);

  return (
    <ThemeProvider>
      <div className="p-8">
        <Button onClick={() => setOpen(true)} data-testid="button-open-search">
          Open Search Dialog
        </Button>
        <SearchDialog
          open={open}
          onOpenChange={setOpen}
          onResultClick={(subjectId, chapterId, lessonId) =>
            console.log(`Navigate to: ${subjectId}/${chapterId}/${lessonId}`)
          }
        />
      </div>
    </ThemeProvider>
  );
}
