import { ThemeProvider } from "../ThemeProvider";
import { GradeSelector } from "../GradeSelector";
import { grades } from "@/lib/mockData";

export default function GradeSelectorExample() {
  return (
    <ThemeProvider>
      <GradeSelector grades={grades} />
    </ThemeProvider>
  );
}
