import { ThemeProvider } from "../ThemeProvider";
import { Navbar } from "../Navbar";

export default function NavbarExample() {
  return (
    <ThemeProvider>
      <div className="min-h-screen">
        <Navbar
          breadcrumbs={[
            { label: "Class 7", href: "/grade/7" },
            { label: "Mathematics", href: "/grade/7/math" },
            { label: "Integers", href: "/grade/7/math/1" },
          ]}
          onSearchClick={() => console.log("Search clicked")}
        />
        <div className="p-8">
          <p className="text-muted-foreground">Content area below navbar</p>
        </div>
      </div>
    </ThemeProvider>
  );
}
