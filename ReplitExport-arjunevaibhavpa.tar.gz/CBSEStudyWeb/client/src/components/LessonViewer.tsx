import { Card } from "@/components/ui/card";
import type { Lesson } from "@shared/schema";

interface LessonViewerProps {
  lesson: Lesson;
  chapterTitle: string;
  chapterNumber: number;
}

export function LessonViewer({
  lesson,
  chapterTitle,
  chapterNumber,
}: LessonViewerProps) {
  return (
    <div className="max-w-4xl mx-auto">
      <Card className="p-8">
        <div className="mb-6">
          <p className="text-sm text-muted-foreground mb-2">
            Chapter {chapterNumber}: {chapterTitle}
          </p>
          <h1 className="font-heading font-bold text-3xl">{lesson.title}</h1>
        </div>

        <div className="prose prose-lg max-w-none">
          <div className="text-lg leading-loose space-y-4">
            {lesson.content.split("\n\n").map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
        </div>

        <div className="mt-8 p-4 bg-muted/50 rounded-lg">
          <p className="text-sm text-muted-foreground text-center">
            More interactive content and practice exercises coming soon
          </p>
        </div>
      </Card>
    </div>
  );
}
