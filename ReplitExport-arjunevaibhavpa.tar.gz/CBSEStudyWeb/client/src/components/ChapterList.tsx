import { useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { Chapter } from "@shared/schema";

interface ChapterListProps {
  chapters: Chapter[];
  onLessonClick: (chapterId: string, lessonId: string) => void;
}

export function ChapterList({ chapters, onLessonClick }: ChapterListProps) {
  const [expandedChapters, setExpandedChapters] = useState<Set<string>>(
    new Set([chapters[0]?.id])
  );

  const toggleChapter = (chapterId: string) => {
    const newExpanded = new Set(expandedChapters);
    if (newExpanded.has(chapterId)) {
      newExpanded.delete(chapterId);
    } else {
      newExpanded.add(chapterId);
    }
    setExpandedChapters(newExpanded);
  };

  return (
    <div className="space-y-4">
      {chapters.map((chapter) => {
        const isExpanded = expandedChapters.has(chapter.id);
        return (
          <div
            key={chapter.id}
            className="border rounded-lg overflow-hidden"
            data-testid={`chapter-${chapter.id}`}
          >
            <button
              onClick={() => toggleChapter(chapter.id)}
              className="w-full flex items-center justify-between p-4 hover-elevate active-elevate-2"
              data-testid={`button-chapter-toggle-${chapter.id}`}
            >
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="font-medium">
                  {chapter.number}
                </Badge>
                <h3 className="font-heading font-medium text-lg text-left">
                  {chapter.title}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">
                  {chapter.lessons.length} lessons
                </span>
                {isExpanded ? (
                  <ChevronDown className="h-5 w-5" />
                ) : (
                  <ChevronRight className="h-5 w-5" />
                )}
              </div>
            </button>

            {isExpanded && (
              <div className="border-t bg-muted/30">
                {chapter.lessons.map((lesson, index) => (
                  <button
                    key={lesson.id}
                    onClick={() => onLessonClick(chapter.id, lesson.id)}
                    className="w-full flex items-center gap-3 px-4 py-3 hover-elevate active-elevate-2 text-left border-b last:border-b-0"
                    data-testid={`button-lesson-${lesson.id}`}
                  >
                    <span className="text-sm text-muted-foreground min-w-[2rem]">
                      {chapter.number}.{index + 1}
                    </span>
                    <span className="text-base">{lesson.title}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
