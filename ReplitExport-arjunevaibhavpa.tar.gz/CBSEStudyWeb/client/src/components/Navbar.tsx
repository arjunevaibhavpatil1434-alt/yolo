import { Link } from "wouter";
import { Home, Search, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./ThemeToggle";

interface NavbarProps {
  breadcrumbs?: { label: string; href: string }[];
  onSearchClick?: () => void;
}

export function Navbar({ breadcrumbs = [], onSearchClick }: NavbarProps) {
  return (
    <header className="sticky top-0 z-50 border-b bg-background">
      <div className="flex items-center justify-between h-16 px-6">
        <div className="flex items-center gap-4">
          <Link href="/">
            <div className="flex items-center gap-2 hover-elevate active-elevate-2 rounded-lg px-3 py-2 cursor-pointer" data-testid="link-home">
              <Home className="h-5 w-5 text-primary" />
              <span className="font-heading font-semibold text-lg hidden sm:inline">
                CBSE Learning
              </span>
            </div>
          </Link>
          
          {breadcrumbs.length > 0 && (
            <nav className="hidden md:flex items-center gap-2 text-sm">
              {breadcrumbs.map((crumb, index) => (
                <div key={index} className="flex items-center gap-2">
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  <Link href={crumb.href}>
                    <span className="text-muted-foreground hover:text-foreground transition-colors cursor-pointer" data-testid={`link-breadcrumb-${index}`}>
                      {crumb.label}
                    </span>
                  </Link>
                </div>
              ))}
            </nav>
          )}
        </div>

        <div className="flex items-center gap-2">
          {onSearchClick && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onSearchClick}
              data-testid="button-search"
            >
              <Search className="h-5 w-5" />
            </Button>
          )}
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
