import type { Subject } from "@shared/schema";
import { SubjectCard } from "./SubjectCard";

interface SubjectDashboardProps {
  grade: number;
  subjects: Subject[];
  onSubjectClick: (subjectId: string) => void;
}

export function SubjectDashboard({
  grade,
  subjects,
  onSubjectClick,
}: SubjectDashboardProps) {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="mb-12">
          <h1 className="font-heading font-bold text-4xl mb-2">
            Class {grade}
          </h1>
          <p className="text-lg text-muted-foreground">
            Choose a subject to explore chapters and lessons
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map((subject) => (
            <SubjectCard
              key={subject.id}
              subject={subject}
              onClick={() => onSubjectClick(subject.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
