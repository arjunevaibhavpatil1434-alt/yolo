import { Card } from "@/components/ui/card";
import type { Subject } from "@shared/schema";
import mathIcon from "@assets/generated_images/Mathematics_subject_icon_10d3e609.png";
import scienceIcon from "@assets/generated_images/Science_subject_icon_b9e47717.png";
import socialIcon from "@assets/generated_images/Social_Studies_subject_icon_0f7446d6.png";
import englishIcon from "@assets/generated_images/English_subject_icon_bf3b4bf0.png";
import hindiIcon from "@assets/generated_images/Hindi_subject_icon_11531e75.png";

const iconMap: Record<string, string> = {
  math: mathIcon,
  science: scienceIcon,
  social: socialIcon,
  english: englishIcon,
  hindi: hindiIcon,
};

interface SubjectCardProps {
  subject: Subject;
  onClick?: () => void;
}

export function SubjectCard({ subject, onClick }: SubjectCardProps) {
  return (
    <Card
      className="h-48 p-6 flex flex-col items-center justify-center gap-4 hover-elevate active-elevate-2 cursor-pointer transition-shadow"
      onClick={onClick}
      data-testid={`card-subject-${subject.id}`}
    >
      <div className="w-20 h-20 flex items-center justify-center">
        <img
          src={iconMap[subject.icon]}
          alt={subject.name}
          className="w-full h-full object-contain rounded-lg"
        />
      </div>
      <div className="text-center">
        <h3 className="font-heading font-semibold text-xl mb-1">
          {subject.name}
        </h3>
        <p className="text-sm text-muted-foreground">
          {subject.description}
        </p>
      </div>
    </Card>
  );
}
