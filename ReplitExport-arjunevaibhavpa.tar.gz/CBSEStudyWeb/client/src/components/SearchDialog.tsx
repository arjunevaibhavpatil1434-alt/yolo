import { useState, useEffect } from "react";
import { Search, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import type { Subject, Chapter } from "@shared/schema";

interface SearchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onResultClick?: (subjectId: string, chapterId: string, lessonId: string) => void;
}

export function SearchDialog({ open, onOpenChange, onResultClick }: SearchDialogProps) {
  const [query, setQuery] = useState("");

  const { data: subjects } = useQuery<Subject[]>({
    queryKey: ["/api/subjects"],
  });

  const [allChapters, setAllChapters] = useState<
    Array<{ subjectId: string; chapters: Chapter[] }>
  >([]);

  useEffect(() => {
    if (subjects && open) {
      Promise.all(
        subjects.map(async (subject) => {
          const res = await fetch(`/api/subjects/${subject.id}/chapters`);
          const chapters = await res.json();
          return { subjectId: subject.id, chapters };
        })
      ).then(setAllChapters);
    }
  }, [subjects, open]);

  const searchResults = query.trim().length > 0
    ? allChapters.flatMap(({ subjectId, chapters }) => {
        const subject = subjects?.find((s) => s.id === subjectId);
        return chapters.flatMap((chapter) =>
          chapter.lessons
            .filter((lesson) =>
              lesson.title.toLowerCase().includes(query.toLowerCase()) ||
              lesson.content.toLowerCase().includes(query.toLowerCase()) ||
              chapter.title.toLowerCase().includes(query.toLowerCase())
            )
            .map((lesson) => ({
              subjectId,
              subjectName: subject?.name || "",
              chapterId: chapter.id,
              chapterTitle: chapter.title,
              lesson,
            }))
        );
      })
    : [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Search Lessons</DialogTitle>
        </DialogHeader>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search for topics, chapters, or lessons..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-9 pr-9"
            data-testid="input-search"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2"
              data-testid="button-clear-search"
            >
              <X className="h-4 w-4 text-muted-foreground" />
            </button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto mt-4 space-y-2">
          {query.trim().length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              Start typing to search across all subjects and lessons
            </p>
          ) : searchResults.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No results found for "{query}"
            </p>
          ) : (
            searchResults.map((result, index) => (
              <button
                key={index}
                onClick={() => {
                  onResultClick?.(result.subjectId, result.chapterId, result.lesson.id);
                  onOpenChange(false);
                  setQuery("");
                }}
                className="w-full p-4 rounded-lg border hover-elevate active-elevate-2 text-left"
                data-testid={`search-result-${index}`}
              >
                <div className="flex items-start gap-2 mb-2">
                  <Badge variant="secondary">{result.subjectName}</Badge>
                </div>
                <h4 className="font-medium mb-1">{result.lesson.title}</h4>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {result.chapterTitle} • {result.lesson.content.substring(0, 100)}...
                </p>
              </button>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
