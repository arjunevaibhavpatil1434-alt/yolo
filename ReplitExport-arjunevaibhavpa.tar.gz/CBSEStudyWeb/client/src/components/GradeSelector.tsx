import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import type { Grade } from "@shared/schema";
import heroImage from "@assets/generated_images/Students_learning_together_hero_0ccc83e4.png";

interface GradeSelectorProps {
  grades: Grade[];
}

export function GradeSelector({ grades }: GradeSelectorProps) {
  return (
    <div className="min-h-screen bg-background">
      <div
        className="relative h-64 bg-gradient-to-br from-primary/90 to-primary flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(to bottom right, hsl(var(--primary) / 0.92), hsl(var(--primary) / 0.88)), url(${heroImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="relative z-10 text-center px-6">
          <h1 className="font-heading font-bold text-4xl md:text-5xl text-white mb-4">
            Welcome to CBSE Learning
          </h1>
          <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto">
            Interactive study materials and lessons for middle school students
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-16">
        <h2 className="font-heading font-semibold text-2xl text-center mb-12">
          Select Your Class
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {grades.map((grade) => (
            <Link key={grade.id} href={`/grade/${grade.id}`}>
              <Card className="h-48 flex flex-col items-center justify-center gap-4 hover-elevate active-elevate-2 cursor-pointer transition-shadow" data-testid={`link-grade-${grade.id}`}>
                <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-heading font-bold text-4xl text-primary">
                    {grade.id}
                  </span>
                </div>
                <div className="text-center">
                  <h3 className="font-heading font-semibold text-xl mb-1">
                    {grade.name}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {grade.description}
                  </p>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
