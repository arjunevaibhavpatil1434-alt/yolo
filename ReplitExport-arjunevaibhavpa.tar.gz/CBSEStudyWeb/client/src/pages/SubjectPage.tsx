import { useLocation, useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/Navbar";
import { ChapterList } from "@/components/ChapterList";
import { SearchDialog } from "@/components/SearchDialog";
import { useState } from "react";
import type { Subject, Chapter } from "@shared/schema";

export default function SubjectPage() {
  const [, params] = useRoute("/grade/:gradeId/subject/:subjectId");
  const [, setLocation] = useLocation();
  const [searchOpen, setSearchOpen] = useState(false);

  const gradeId = params?.gradeId || "6";
  const subjectId = params?.subjectId || "math";

  const { data: subjects } = useQuery<Subject[]>({
    queryKey: ["/api/subjects"],
  });

  const { data: chapters, isLoading } = useQuery<Chapter[]>({
    queryKey: ["/api/subjects", subjectId, "chapters"],
    queryFn: async () => {
      const res = await fetch(`/api/subjects/${subjectId}/chapters`);
      if (!res.ok) throw new Error("Failed to fetch chapters");
      return res.json();
    },
  });

  const subject = subjects?.find((s) => s.id === subjectId);

  const handleLessonClick = (chapterId: string, lessonId: string) => {
    setLocation(`/grade/${gradeId}/subject/${subjectId}/lesson/${lessonId}`);
  };

  const handleSearchResult = (subjectId: string, chapterId: string, lessonId: string) => {
    setLocation(`/grade/${gradeId}/subject/${subjectId}/lesson/${lessonId}`);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar
          breadcrumbs={[
            { label: `Class ${gradeId}`, href: `/grade/${gradeId}` },
            { label: subject?.name || "", href: `/grade/${gradeId}/subject/${subjectId}` },
          ]}
          onSearchClick={() => setSearchOpen(true)}
        />
        <div className="flex items-center justify-center py-20">
          <div className="text-lg text-muted-foreground">Loading chapters...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar
        breadcrumbs={[
          { label: `Class ${gradeId}`, href: `/grade/${gradeId}` },
          { label: subject?.name || "", href: `/grade/${gradeId}/subject/${subjectId}` },
        ]}
        onSearchClick={() => setSearchOpen(true)}
      />
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="font-heading font-bold text-4xl mb-2">
            {subject?.name}
          </h1>
          <p className="text-lg text-muted-foreground">
            {subject?.description}
          </p>
        </div>
        <ChapterList chapters={chapters || []} onLessonClick={handleLessonClick} />
      </div>
      <SearchDialog
        open={searchOpen}
        onOpenChange={setSearchOpen}
        onResultClick={handleSearchResult}
      />
    </div>
  );
}
