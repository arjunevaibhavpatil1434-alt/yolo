import { useLocation, useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { SubjectDashboard } from "@/components/SubjectDashboard";
import { Navbar } from "@/components/Navbar";
import { SearchDialog } from "@/components/SearchDialog";
import { useState } from "react";
import type { Subject } from "@shared/schema";

export default function GradePage() {
  const [, params] = useRoute("/grade/:gradeId");
  const [, setLocation] = useLocation();
  const [searchOpen, setSearchOpen] = useState(false);
  const gradeId = params?.gradeId ? parseInt(params.gradeId) : 6;

  const { data: subjects, isLoading } = useQuery<Subject[]>({
    queryKey: ["/api/subjects"],
  });

  const handleSubjectClick = (subjectId: string) => {
    setLocation(`/grade/${gradeId}/subject/${subjectId}`);
  };

  const handleSearchResult = (subjectId: string, chapterId: string, lessonId: string) => {
    setLocation(`/grade/${gradeId}/subject/${subjectId}/lesson/${lessonId}`);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar
          breadcrumbs={[{ label: `Class ${gradeId}`, href: `/grade/${gradeId}` }]}
          onSearchClick={() => setSearchOpen(true)}
        />
        <div className="flex items-center justify-center py-20">
          <div className="text-lg text-muted-foreground">Loading subjects...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar
        breadcrumbs={[{ label: `Class ${gradeId}`, href: `/grade/${gradeId}` }]}
        onSearchClick={() => setSearchOpen(true)}
      />
      <SubjectDashboard
        grade={gradeId}
        subjects={subjects || []}
        onSubjectClick={handleSubjectClick}
      />
      <SearchDialog
        open={searchOpen}
        onOpenChange={setSearchOpen}
        onResultClick={handleSearchResult}
      />
    </div>
  );
}
