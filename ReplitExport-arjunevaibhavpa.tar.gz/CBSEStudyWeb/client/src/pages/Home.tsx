import { useQuery } from "@tanstack/react-query";
import { GradeSelector } from "@/components/GradeSelector";
import type { Grade } from "@shared/schema";

export default function Home() {
  const { data: grades, isLoading } = useQuery<Grade[]>({
    queryKey: ["/api/grades"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-lg text-muted-foreground">Loading grades...</div>
        </div>
      </div>
    );
  }

  return <GradeSelector grades={grades || []} />;
}
