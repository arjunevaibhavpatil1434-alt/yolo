import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BookOpen, GraduationCap, Sparkles } from "lucide-react";
import heroImage from "@assets/generated_images/Students_learning_together_hero_0ccc83e4.png";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background">
      <div
        className="relative h-96 bg-gradient-to-br from-primary/90 to-primary flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(to bottom right, hsl(var(--primary) / 0.92), hsl(var(--primary) / 0.88)), url(${heroImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="relative z-10 text-center px-6 max-w-4xl">
          <h1 className="font-heading font-bold text-5xl md:text-6xl text-white mb-6">
            Master CBSE Curriculum with Interactive Learning
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8">
            Comprehensive study materials for Classes 6, 7, and 8 across all core subjects
          </p>
          <Button
            size="lg"
            onClick={handleLogin}
            className="text-lg px-8 py-6 h-auto"
            data-testid="button-login"
          >
            Get Started
          </Button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-20">
        <h2 className="font-heading font-bold text-3xl text-center mb-12">
          Why Choose CBSE Learning?
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          <Card className="p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <BookOpen className="h-8 w-8 text-primary" />
            </div>
            <h3 className="font-heading font-semibold text-xl mb-3">
              Comprehensive Content
            </h3>
            <p className="text-muted-foreground">
              Complete coverage of Mathematics, Science, Social Studies, English, and Hindi aligned with CBSE curriculum
            </p>
          </Card>

          <Card className="p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <GraduationCap className="h-8 w-8 text-primary" />
            </div>
            <h3 className="font-heading font-semibold text-xl mb-3">
              Easy to Understand
            </h3>
            <p className="text-muted-foreground">
              Clear explanations and well-structured lessons make complex topics simple to grasp
            </p>
          </Card>

          <Card className="p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <Sparkles className="h-8 w-8 text-primary" />
            </div>
            <h3 className="font-heading font-semibold text-xl mb-3">
              Anytime, Anywhere
            </h3>
            <p className="text-muted-foreground">
              Access your study materials on any device, whether at home or on the go
            </p>
          </Card>
        </div>

        <div className="text-center">
          <h2 className="font-heading font-bold text-2xl mb-4">
            Ready to Start Learning?
          </h2>
          <p className="text-lg text-muted-foreground mb-6">
            Sign in to access personalized learning materials and track your progress
          </p>
          <Button
            size="lg"
            onClick={handleLogin}
            data-testid="button-login-footer"
          >
            Sign In to Continue
          </Button>
        </div>
      </div>
    </div>
  );
}
