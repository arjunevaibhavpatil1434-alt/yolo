import { useRoute, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/Navbar";
import { LessonViewer } from "@/components/LessonViewer";
import { SearchDialog } from "@/components/SearchDialog";
import { useState } from "react";
import type { Subject } from "@shared/schema";

export default function LessonPage() {
  const [, params] = useRoute("/grade/:gradeId/subject/:subjectId/lesson/:lessonId");
  const [, setLocation] = useLocation();
  const [searchOpen, setSearchOpen] = useState(false);

  const gradeId = params?.gradeId || "6";
  const subjectId = params?.subjectId || "math";
  const lessonId = params?.lessonId || "";

  const { data: subjects } = useQuery<Subject[]>({
    queryKey: ["/api/subjects"],
  });

  const { data: lessonData, isLoading } = useQuery({
    queryKey: ["/api/lessons", lessonId],
    queryFn: async () => {
      const res = await fetch(`/api/lessons/${lessonId}`);
      if (!res.ok) throw new Error("Failed to fetch lesson");
      return res.json();
    },
  });

  const subject = subjects?.find((s) => s.id === subjectId);

  const handleSearchResult = (subjectId: string, chapterId: string, lessonId: string) => {
    setLocation(`/grade/${gradeId}/subject/${subjectId}/lesson/${lessonId}`);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar
          breadcrumbs={[
            { label: `Class ${gradeId}`, href: `/grade/${gradeId}` },
            { label: subject?.name || "", href: `/grade/${gradeId}/subject/${subjectId}` },
          ]}
          onSearchClick={() => setSearchOpen(true)}
        />
        <div className="flex items-center justify-center py-20">
          <div className="text-lg text-muted-foreground">Loading lesson...</div>
        </div>
      </div>
    );
  }

  if (!lessonData) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center py-20">
          <div className="text-lg text-muted-foreground">Lesson not found</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar
        breadcrumbs={[
          { label: `Class ${gradeId}`, href: `/grade/${gradeId}` },
          { label: subject?.name || "", href: `/grade/${gradeId}/subject/${subjectId}` },
          { label: lessonData.chapter.title, href: `/grade/${gradeId}/subject/${subjectId}` },
        ]}
        onSearchClick={() => setSearchOpen(true)}
      />
      <div className="px-6 py-12">
        <LessonViewer
          lesson={lessonData.lesson}
          chapterTitle={lessonData.chapter.title}
          chapterNumber={lessonData.chapter.number}
        />
      </div>
      <SearchDialog
        open={searchOpen}
        onOpenChange={setSearchOpen}
        onResultClick={handleSearchResult}
      />
    </div>
  );
}
