# CBSE Learning - Educational Web App

## Overview
A comprehensive web application for CBSE (Central Board of Secondary Education) students in grades 6-8. The app provides organized access to subject-wise lessons and study materials aligned with the CBSE curriculum.

## Target Audience
Students in Classes 6, 7, and 8 studying under the CBSE board.

## Core Features
- **Grade Selection**: Choose from Classes 6, 7, or 8
- **Subject Dashboard**: Access five core subjects:
  - Mathematics
  - Science
  - Social Studies
  - English
  - Hindi
- **Chapter Browser**: Expandable chapter lists with lesson counts
- **Lesson Viewer**: Clean, readable lesson content with proper formatting
- **Global Search**: Search across all subjects and lessons by title or content
- **Theme Support**: Light and dark mode toggle for comfortable reading
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices

## Project Architecture

### Frontend (React + TypeScript)
- **Framework**: React with Vite
- **Routing**: Wouter for client-side navigation
- **State Management**: TanStack Query for server state
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Shadcn UI library
- **Fonts**: Inter (body), Poppins (headings)

### Backend (Express.js)
- **API Routes**:
  - `GET /api/grades` - Fetch all available grades
  - `GET /api/subjects` - Fetch all subjects
  - `GET /api/subjects/:subjectId/chapters` - Fetch chapters for a subject
  - `GET /api/lessons/:lessonId` - Fetch specific lesson with chapter context
- **Storage**: In-memory storage with educational content

### Data Structure
```typescript
Grade: { id, name, description }
Subject: { id, name, icon, description, color }
Chapter: { id, number, title, lessons[] }
Lesson: { id, title, content }
```

## Navigation Flow
```
Homepage (/) 
  → Grade Selection (/grade/:gradeId)
    → Subject Dashboard (/grade/:gradeId/subject/:subjectId)
      → Lesson View (/grade/:gradeId/subject/:subjectId/lesson/:lessonId)
```

## Current Content
The application includes sample educational content for all five subjects across multiple chapters:
- **Mathematics**: Integers, Fractions and Decimals, Ratio and Proportion
- **Science**: Nutrition in Plants, Acids Bases and Salts
- **Social Studies**: The Mughal Empire, Medieval India
- **English**: Parts of Speech, Reading Comprehension
- **Hindi**: वर्ण और मात्राएं, संज्ञा और सर्वनाम

## Design System
- **Color Scheme**: Blue primary color (education-focused)
- **Typography**: Clear hierarchy with Poppins headings and Inter body text
- **Spacing**: Consistent spacing scale (small, medium, large)
- **Components**: Reusable cards, buttons, badges, and navigation elements
- **Interactions**: Subtle hover and active states following design guidelines

## Recent Changes
- Created complete frontend prototype with all components
- Implemented backend API routes for educational content
- Connected frontend to backend using TanStack Query
- Added comprehensive search functionality
- Fixed React warnings (nested anchor tags)
- Successfully tested end-to-end user flows

## Future Enhancements
- Interactive practice quizzes and exercises
- Bookmark and favorites system
- Progress tracking dashboard
- Video tutorial integration
- Downloadable PDF study materials
- User authentication for personalized learning
- Database persistence for user progress

## Running the Project
The application runs on port 5000 with:
- Express backend serving API routes
- Vite development server for frontend
- Hot module replacement for rapid development

## Testing
End-to-end testing conducted using Playwright covering:
- Grade and subject navigation
- Chapter expansion and lesson viewing
- Search functionality
- Theme toggling
- Breadcrumb navigation
