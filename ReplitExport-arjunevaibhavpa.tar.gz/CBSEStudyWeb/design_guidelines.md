# Design Guidelines: CBSE Education Web App (Grades 6-8)

## Design Approach

**Selected Framework**: Material Design principles with inspiration from Khan Academy and educational platforms
**Rationale**: Utility-focused educational tool requiring clarity, consistency, and age-appropriate interface for students aged 11-14

## Typography

**Font Families**:
- Primary: Inter (via Google Fonts CDN) - body text, navigation, UI elements
- Headings: Poppins (via Google Fonts CDN) - page titles, section headers

**Type Scale**:
- Page Titles: text-4xl font-bold (Poppins)
- Section Headers: text-2xl font-semibold (Poppins)
- Card Titles/Subject Names: text-xl font-medium (Poppins)
- Body Text: text-base leading-relaxed (Inter)
- Lesson Content: text-lg leading-loose for optimal readability (Inter)
- Navigation/Buttons: text-sm font-medium uppercase tracking-wide (Inter)
- Metadata (chapter numbers, dates): text-sm (Inter)

## Layout System

**Spacing Primitives**: Consistent use of Tailwind units: 4, 6, 8, 12, 16, 20
- Component padding: p-6 or p-8
- Section spacing: py-12 or py-16
- Card gaps: gap-6 or gap-8
- Element margins: mb-4, mb-6, mb-8

**Container Strategy**:
- Main content: max-w-7xl mx-auto px-6
- Reading content (lessons): max-w-4xl mx-auto for optimal line length
- Wide layouts (subject grids): max-w-6xl mx-auto

**Grid Patterns**:
- Grade selection: 3 large cards (grid-cols-1 md:grid-cols-3 gap-6)
- Subject cards: grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6
- Lesson lists: Single column with clear hierarchy

## Navigation Structure

**Primary Navigation**:
- Fixed top navbar with logo, grade indicator, breadcrumb navigation
- Height: h-16
- Prominent "Home" and "Search" options
- User profile/settings in top-right

**Breadcrumb Trail**:
- Always visible: Grade > Subject > Chapter > Lesson
- Clickable path for easy navigation back
- Spacing: gap-2 with separator icons (Heroicons chevron-right)

## Component Library

### Grade Selection Page
- Hero section with welcoming headline: "Welcome to CBSE Learning" (h-64 with gradient background)
- Three prominent grade cards (Class 6, 7, 8) with:
  - Large centered number/icon
  - "Class [X]" heading
  - Brief descriptor text
  - Rounded-xl borders with shadow-lg on hover

### Subject Dashboard
- Page header with selected grade prominently displayed
- Subject cards grid displaying all CBSE subjects:
  - Icons from Heroicons (book-open, beaker, globe, etc.)
  - Subject name
  - Chapter count indicator
  - Rounded-lg with hover elevation effect
  - Consistent card height (h-48)

### Chapter Browser
- Subject header with icon and name
- List of chapters as expandable cards:
  - Chapter number badge
  - Chapter title
  - Lesson count
  - Expand/collapse icon (Heroicons chevron-down)
  - Nested lesson list when expanded

### Lesson Content Page
- Split layout on desktop:
  - Left sidebar (w-80): Chapter navigation with current lesson highlighted
  - Main content area: Lesson content with generous padding
- Lesson header: Chapter context + lesson title
- Content area with:
  - Clear heading hierarchy (h1, h2, h3)
  - Well-spaced paragraphs (space-y-4)
  - Lists with proper indentation
  - Embedded resource cards (rounded-lg border)

### Search Interface
- Prominent search bar: h-12 with rounded-full design
- Search results as cards showing:
  - Subject badge
  - Grade badge
  - Chapter and lesson title
  - Snippet of content
  - Click to navigate

## Interactive Elements

**Buttons**:
- Primary actions: px-6 py-3 rounded-lg font-medium
- Secondary actions: px-4 py-2 rounded-md
- Icon buttons: p-2 rounded-full
- All buttons implement standard hover states

**Cards**:
- Consistent rounded-lg or rounded-xl
- Shadow-md default, shadow-xl on hover
- Smooth transition (transition-shadow duration-300)
- Clickable cards: cursor-pointer with subtle scale on hover

**Resource Embeds**:
- YouTube videos: aspect-video with rounded-lg overflow-hidden
- PDF viewers: embedded in rounded-lg container with border
- Images: rounded-lg with proper aspect ratios

## Icons

**Icon Library**: Heroicons (via CDN)
**Usage**:
- Subject icons: 24x24 size (w-6 h-6)
- Navigation icons: 20x20 size (w-5 h-5)
- Inline icons with text: 16x16 size (w-4 h-4)
- Consistent stroke-width: 2

## Responsive Behavior

**Mobile-First Approach**:
- Stack all grids to single column on mobile
- Collapsible sidebar navigation (hamburger menu)
- Simplified breadcrumb on small screens (show only current location)
- Touch-friendly tap targets (minimum h-12)

**Breakpoint Strategy**:
- Mobile: Base styles, single column
- Tablet (md:): 2-column grids where appropriate
- Desktop (lg:): Full multi-column layouts, sidebar navigation

## Accessibility

- All interactive elements keyboard navigable
- Focus rings visible on all focusable elements (ring-2 ring-offset-2)
- Proper heading hierarchy (h1 → h6) for screen readers
- Alt text for all icons and images
- Sufficient contrast ratios maintained throughout
- Form inputs with proper labels and aria-labels

## Images

**Hero Section**: 
- Homepage hero with illustration of students learning (abstract, friendly style)
- Height: h-64 on desktop, h-48 on mobile
- Placement: Top of grade selection page

**Subject Icons**:
- Use Heroicons or custom subject-specific illustrations
- Consistent 80x80 size for subject cards
- Simple, recognizable symbols

**Lesson Content**:
- Diagrams and educational images embedded within content
- Always with rounded-lg borders
- Proper captions below images

No large background images on content pages to maintain focus on learning materials.