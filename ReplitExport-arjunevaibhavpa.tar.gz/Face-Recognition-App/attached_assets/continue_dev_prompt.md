# VisionSentry — Real-Time Face Recognition & CCTV Surveillance Platform
## Master Build Prompt for continue.dev

> Paste this entire document as a single prompt into continue.dev (or use it as the project's `.continue/rules.md`). It is the complete, end-to-end specification for an advanced, production-grade face recognition + CCTV surveillance application using **RetinaFace + ArcFace + FAISS + ByteTrack + ONNX Runtime**.

---

## 1. Role & Mission

You are a senior computer-vision and distributed-systems engineer. Build **VisionSentry**, a production-grade, real-time face recognition and CCTV surveillance platform. Generate complete, runnable code (no pseudo-code, no TODOs), with type hints, docstrings, error handling, structured logging, unit tests, Dockerfiles, Compose stack, Kubernetes manifests, and a working React dashboard.

Deliver the project incrementally, phase by phase. After each phase, output:
1. The full file tree touched
2. Every file's complete contents
3. Run / test commands
4. A short "what changed and why" note

Do **not** stub anything that real users will touch (enrollment, live recognition, watchlist alerts, audit log writes). Mocks are only allowed for hardware not present in the dev environment (e.g., a real RTSP camera) and must be clearly flagged with `# MOCK:`.

---

## 2. Product Summary

VisionSentry ingests multiple RTSP CCTV streams, detects and tracks faces in real time, matches them against an enrolled identity database, fires watchlist alerts, and exposes a live operator dashboard. It must support 16+ concurrent 1080p streams per GPU node at <100 ms end-to-end latency and scale to 1M+ enrolled identities with <5 ms ANN search.

### Primary users
- **Admin** — enrolls people, manages watchlists, configures cameras, manages users
- **Operator** — monitors live feeds, acknowledges alerts, runs ad-hoc photo searches
- **Viewer** — read-only dashboard and event history

---

## 3. Locked Tech Stack (do not substitute)

| Layer | Choice | Reason |
|---|---|---|
| Face detection | **RetinaFace (ONNX)** | Robust to occlusion, small faces, CCTV angles; outputs 5-pt landmarks for alignment |
| Face embedding | **ArcFace ResNet-100 (ONNX, 512-dim, L2-normalised)** | Best-in-class surveillance accuracy |
| Vector search | **FAISS (IVF-PQ + HNSW)** | Sub-5 ms ANN at millions of vectors |
| Identity store | **PostgreSQL 16 + pgvector** | Hybrid SQL + vector queries, audit trail |
| Tracker | **ByteTrack** | Maintains stable `track_id`; embed once per new track |
| Inference runtime | **ONNX Runtime (CUDAExecutionProvider, fallback CPU)** | 3–5× faster than PyTorch eager, portable |
| Anti-spoofing | **Silent-Face ONNX** | Blocks photo / video replay attacks |
| Stream bus | **Redis Streams** (Kafka optional for scale) | Decouples RTSP readers from GPU workers |
| Backend API | **FastAPI + Uvicorn + Pydantic v2** | Async, typed, auto-OpenAPI |
| ORM / migrations | **SQLAlchemy 2.x + Alembic** | |
| Auth | **OAuth2 password flow + JWT, RBAC** (admin / operator / viewer) | |
| Alerting | **MQTT (paho-mqtt) + HTTP webhooks + SMTP + WebSocket push** | |
| Frontend | **React 18 + Vite + TypeScript + TailwindCSS + shadcn/ui + TanStack Query + Zustand + Recharts** | |
| Live feed | **MJPEG over HTTP + WebSocket events** | |
| Observability | **Prometheus + Grafana + Loki + OpenTelemetry traces** | |
| Container | **Docker (CUDA 12.1 base) + docker-compose + Helm chart with NVIDIA device plugin** | |
| CI | **GitHub Actions: lint (ruff, black, mypy), pytest, build images, trivy scan** | |

### Core Python libraries (pin versions in `requirements.txt`)
```
opencv-python-headless
numpy
onnxruntime-gpu          # fallback: onnxruntime
insightface              # RetinaFace + ArcFace model weights
faiss-gpu                # fallback: faiss-cpu
psycopg[binary]
pgvector
sqlalchemy>=2
alembic
redis>=5
fastapi
uvicorn[standard]
pydantic>=2
python-jose[cryptography]
passlib[bcrypt]
paho-mqtt
httpx
ultralytics              # optional fallback detector
deep-sort-realtime       # ByteTrack/DeepSORT wrapper
prometheus-client
opentelemetry-sdk
pytest, pytest-asyncio, pytest-cov, ruff, black, mypy
```

---

## 4. Performance & Scale Targets (must be measurable)

- End-to-end latency (frame capture → recognition event): **< 100 ms** on a single RTX 3090 / A10G
- Throughput: **≥ 16 concurrent 1080p RTSP streams per GPU node**
- Detection FPS per stream: **5–10 FPS** (ByteTrack interpolates the rest)
- ANN search: **< 5 ms** for 1M embeddings (FAISS HNSW or IVF-PQ)
- Enrollment scale: **100K+ identities** before any index rebuild
- Cold start of one camera worker: **< 3 s**
- API p99 latency (non-search): **< 150 ms**

Include a `tests/bench_pipeline.py` that prints these numbers.

---

## 5. Repository Layout (create exactly this)

```
face-surveillance/
├── core/
│   ├── __init__.py
│   ├── detector.py          # RetinaFace ONNX wrapper, NMS, 5-pt landmarks
│   ├── aligner.py           # 5-point affine warp → 112x112
│   ├── embedder.py          # ArcFace ONNX session, batch infer, L2 normalise
│   ├── matcher.py           # FAISS IVF-PQ + HNSW, cosine search, threshold
│   ├── tracker.py           # ByteTrack wrapper, track_id lifecycle
│   ├── quality.py           # Blur, pose, brightness, size quality filter
│   └── antispoof.py         # Silent-Face ONNX liveness check
├── ingestion/
│   ├── rtsp_reader.py       # OpenCV multi-threaded RTSP, frame → Redis Streams
│   └── stream_manager.py    # Camera registry, health-check, auto-reconnect
├── pipeline/
│   ├── worker.py            # Per-camera: read → detect → align → embed → match → track → emit
│   └── orchestrator.py      # Multi-camera process pool, GPU assignment, backpressure
├── database/
│   ├── models.py            # SQLAlchemy models (see schema below)
│   ├── session.py
│   ├── faiss_store.py       # FAISS save/load, hot-reload, sharding, dual-write with pgvector
│   └── migrations/          # Alembic
├── api/
│   ├── main.py              # FastAPI app, CORS, JWT, OpenTelemetry, Prometheus /metrics
│   ├── deps.py
│   ├── auth.py              # OAuth2 + RBAC
│   └── routes/
│       ├── enroll.py        # POST /enroll  (multi-photo), DELETE /persons/{id}
│       ├── persons.py       # CRUD persons + role
│       ├── search.py        # POST /search (ad-hoc photo query)
│       ├── events.py        # GET /events (filter), WS /ws/live, GET /events/{id}/frame
│       ├── watchlist.py     # Watchlist CRUD + severity
│       ├── cameras.py       # Camera CRUD, health, snapshot
│       └── stats.py         # Dashboard counters, throughput, alerts/hr
├── alerting/
│   ├── dispatcher.py        # Routes events → MQTT / Webhook / SMTP / WS
│   ├── mqtt_publisher.py
│   ├── webhook.py           # Retry with exp backoff, signed payloads
│   └── email_smtp.py
├── compliance/
│   ├── retention.py         # GDPR retention job: blur unknowns, purge after N days
│   └── audit.py             # Immutable append-only audit log writer
├── dashboard/               # React + Vite + TS
│   ├── src/
│   │   ├── App.tsx
│   │   ├── pages/
│   │   │   ├── LiveGrid.tsx        # 1×1 / 2×2 / 3×3 / 4×4 MJPEG grid with overlays
│   │   │   ├── PersonsLog.tsx      # persons_log table (search, filters, simulate)
│   │   │   ├── EmbeddingsTable.tsx # 512-dim vector preview, L2 norm, infer ms
│   │   │   ├── Enroll.tsx          # multi-photo upload + quality preview
│   │   │   ├── Watchlist.tsx       # CRUD + severity
│   │   │   ├── Cameras.tsx         # add/edit RTSP, health
│   │   │   ├── Events.tsx          # filterable event history + frame preview
│   │   │   └── Settings.tsx        # thresholds, retention, users (admin)
│   │   ├── components/
│   │   │   ├── NotificationCenter.tsx  # toast popups: watchlist / match / unknown / system
│   │   │   ├── LiveOverlay.tsx
│   │   │   └── ...
│   │   └── lib/api.ts
├── deploy/
│   ├── Dockerfile               # CUDA 12.1 + Python 3.11
│   ├── Dockerfile.dashboard
│   ├── docker-compose.yml       # api, worker, redis, postgres+pgvector, mqtt, dashboard, prometheus, grafana
│   └── k8s/                     # Helm chart, NVIDIA device plugin, HPA
├── config/
│   ├── config.yaml              # Cameras, thresholds, model paths, alert routes
│   └── models/                  # ONNX weights (download script)
├── scripts/
│   ├── download_models.sh
│   ├── seed_demo.py
│   └── rebuild_faiss.py
├── tests/
│   ├── test_detector.py
│   ├── test_embedder.py
│   ├── test_matcher.py
│   ├── test_pipeline_e2e.py
│   ├── test_api_auth.py
│   └── bench_pipeline.py
├── .github/workflows/ci.yml
├── pyproject.toml
├── requirements.txt
├── README.md
└── Makefile
```

---

## 6. Database Schema (PostgreSQL + pgvector)

Create exactly two visible "log" tables plus supporting tables. Use Alembic migrations.

```sql
-- Extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Master identity record
CREATE TABLE persons (
    person_id    VARCHAR(12) PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    role         VARCHAR(50),
    metadata     JSONB DEFAULT '{}'::jsonb,
    is_active    BOOLEAN DEFAULT TRUE,
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- TABLE 1: persons_log  (every recognition event surfaces here)
CREATE TABLE persons_log (
    id           SERIAL PRIMARY KEY,
    person_id    VARCHAR(12)  NOT NULL,
    name         VARCHAR(100),
    role         VARCHAR(50),
    camera_id    VARCHAR(10)  NOT NULL,
    status       VARCHAR(20)  CHECK (status IN ('matched','watchlist','unknown')),
    confidence   SMALLINT     CHECK (confidence BETWEEN 0 AND 100),
    track_id     VARCHAR(12),
    detected_at  TIMESTAMPTZ  DEFAULT NOW(),
    frame_path   TEXT
);
CREATE INDEX idx_persons_log_status      ON persons_log (status);
CREATE INDEX idx_persons_log_detected_at ON persons_log (detected_at DESC);
CREATE INDEX idx_persons_log_person_id   ON persons_log (person_id);
CREATE INDEX idx_persons_log_camera_id   ON persons_log (camera_id);

-- TABLE 2: face_embeddings  (one row per enrolled embedding)
CREATE TABLE face_embeddings (
    id           SERIAL PRIMARY KEY,
    emb_id       VARCHAR(12)  NOT NULL UNIQUE,
    person_id    VARCHAR(12)  NOT NULL REFERENCES persons(person_id) ON DELETE CASCADE,
    model        VARCHAR(50)  DEFAULT 'ArcFace-R100',
    embedding    VECTOR(512)  NOT NULL,
    l2_norm      FLOAT        DEFAULT 1.0,
    quality      VARCHAR(10)  CHECK (quality IN ('high','medium','low')),
    infer_ms     SMALLINT,
    source_image TEXT,
    created_at   TIMESTAMPTZ  DEFAULT NOW()
);
CREATE INDEX idx_face_emb_person ON face_embeddings (person_id);
CREATE INDEX idx_face_emb_hnsw   ON face_embeddings USING hnsw (embedding vector_cosine_ops);

-- Supporting tables
CREATE TABLE cameras (
    camera_id    VARCHAR(10) PRIMARY KEY,
    name         VARCHAR(100),
    rtsp_url     TEXT NOT NULL,
    zone         VARCHAR(50),
    is_active    BOOLEAN DEFAULT TRUE,
    last_seen    TIMESTAMPTZ
);

CREATE TABLE watchlist (
    id           SERIAL PRIMARY KEY,
    person_id    VARCHAR(12) REFERENCES persons(person_id) ON DELETE CASCADE,
    severity     VARCHAR(10) CHECK (severity IN ('low','medium','high','critical')),
    reason       TEXT,
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    expires_at   TIMESTAMPTZ
);

CREATE TABLE users (
    id           SERIAL PRIMARY KEY,
    username     VARCHAR(50) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role         VARCHAR(20) CHECK (role IN ('admin','operator','viewer')),
    is_active    BOOLEAN DEFAULT TRUE,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE audit_log (   -- append-only
    id           BIGSERIAL PRIMARY KEY,
    actor        VARCHAR(50),
    action       VARCHAR(50),
    target       TEXT,
    payload      JSONB,
    ts           TIMESTAMPTZ DEFAULT NOW()
);
```

FAISS index and `face_embeddings` are **dual-written** via the enrollment API and stay in sync. On startup, FAISS is rebuilt from `face_embeddings` if the snapshot is missing.

---

## 7. Pipeline Contract (per camera worker)

```
RTSP frame  →  Redis Stream (cam:{id})  →  Worker:
  1. Decode + downsample to 720p
  2. RetinaFace detect (ONNX, GPU)         → boxes + landmarks
  3. ByteTrack update                       → track_ids
  4. For each NEW track_id only:
       a. Quality filter (blur, pose, size, brightness)
       b. Anti-spoofing (Silent-Face)
       c. Aligner (5-pt warp → 112x112)
       d. ArcFace embed (batched, L2-norm)
       e. FAISS cosine search (threshold 0.65, configurable)
       f. Resolve identity → cache in Redis (track_id → person_id, TTL 30s)
  5. For existing tracks → reuse cached identity
  6. Emit event (matched / watchlist / unknown):
       - INSERT INTO persons_log
       - INSERT INTO audit_log
       - Save annotated frame to S3/NFS
       - Publish to MQTT, webhooks, WebSocket /ws/live
       - If watchlist → SMTP + push notification
```

Configurable per-camera: FPS, resolution, threshold, watchlist-only mode.

---

## 8. REST + WebSocket API (FastAPI, all JSON, all OpenAPI-documented)

| Method | Path | Role | Purpose |
|---|---|---|---|
| POST | `/auth/login` | any | OAuth2 password → JWT |
| POST | `/persons` | admin | Create person |
| POST | `/enroll` | admin | Upload N photos → quality filter → embed → FAISS + face_embeddings |
| GET | `/persons` | viewer+ | List / search persons |
| DELETE | `/persons/{id}` | admin | Delete person + embeddings + FAISS entries |
| POST | `/search` | operator+ | Ad-hoc photo → top-K matches |
| GET | `/events` | viewer+ | Filter by camera / status / time |
| GET | `/events/{id}/frame` | viewer+ | Annotated frame |
| WS | `/ws/live` | viewer+ | Live event stream + notifications |
| GET | `/cameras` / POST / PUT / DELETE | admin | Camera CRUD |
| GET | `/cameras/{id}/snapshot` | viewer+ | Latest frame |
| GET | `/cameras/{id}/mjpeg` | viewer+ | Live MJPEG stream |
| GET | `/watchlist` / POST / DELETE | admin | Watchlist mgmt |
| GET | `/stats/dashboard` | viewer+ | Counters: matches/hr, watchlist hits, unknowns, active cams |
| GET | `/metrics` | — | Prometheus |

All write endpoints write to `audit_log`. All inputs validated with Pydantic v2. All errors return RFC-7807 problem+json.

---

## 9. React Dashboard (must implement, not stub)

Pages, all responsive, dark-mode default, shadcn/ui:

1. **Live Grid** — 1×1 / 2×2 / 3×3 / 4×4 MJPEG tiles with bbox + identity + confidence overlay; click tile → fullscreen.
2. **Persons Log** — searchable table (by name, person_id, role); filter by status (matched / watchlist / unknown) and camera; **"Simulate event" button** that POSTs a fake event for demo and triggers a notification.
3. **Embeddings Table** — each row shows person_id, emb_id, model, **8-dim sparkline preview of the 512-dim vector** (`+504 implied`), L2 norm (always 1.000), quality badge (high/medium/low), inference ms; filter by quality & person.
4. **Enroll** — drag-drop multiple photos; client-side preview + server-side quality score; submit → progress + per-photo result.
5. **Watchlist** — CRUD with severity color-coded.
6. **Cameras** — add/edit RTSP URL, test connection, show health + last_seen.
7. **Events** — paginated history + frame thumbnail + filters.
8. **Settings** — admin-only: thresholds, retention, user mgmt.

**Notification Center (always mounted):** four notification kinds, each with distinct color, auto-dismiss in 6 s, also stack in a "Clear all" tray:
- `watchlist`  → red, high priority, sound
- `match`      → green, informational
- `unknown`    → amber, needs attention
- `system`     → blue, operational

Notifications come from `/ws/live`. Manual "Simulate notification" buttons for QA.

---

## 10. Build Phases (deliver in this order, one phase per response)

### Phase 1 — Core CV pipeline (single camera, single GPU)
- `core/*`, `ingestion/rtsp_reader.py`, `pipeline/worker.py`
- `database/` models + Alembic migrations + `faiss_store.py`
- CLI: `python -m pipeline.worker --camera-id CAM01 --rtsp <url>`
- Unit tests + a synthetic-video integration test

### Phase 2 — Multi-camera orchestrator + tracking
- `pipeline/orchestrator.py`, ByteTrack integration, Redis Streams backpressure
- Cross-camera re-ID via embedding cache
- `tests/bench_pipeline.py` proving the perf targets

### Phase 3 — FastAPI backend + auth + enrollment
- All routes in §8, JWT + RBAC, OpenAPI docs at `/docs`
- Batch enrollment (auto-align, quality-filter, average N embeddings/person)
- Dual-write FAISS + pgvector

### Phase 4 — Alerting + compliance
- MQTT, webhooks, SMTP, WS dispatcher
- Annotated frame writer (S3/NFS abstraction with local fallback)
- GDPR retention job (blur unknowns, purge old frames)
- Immutable audit log

### Phase 5 — React dashboard
- All pages in §9, NotificationCenter, MJPEG viewer, live WS

### Phase 6 — Deploy + observability
- `Dockerfile` (CUDA 12.1), `docker-compose.yml` (full stack), Helm chart with NVIDIA device plugin + HPA
- Prometheus exporters, Grafana dashboards JSON, Loki log shipping, OTel traces
- GitHub Actions CI

After each phase, output the file tree, every full file, run commands, and a brief changelog.

---

## 11. Coding Standards

- Python 3.11, type hints everywhere, `from __future__ import annotations`
- `ruff` + `black` + `mypy --strict` clean
- Structured logging via `structlog` (JSON in prod, pretty in dev) — **never** `print`
- All config via `pydantic-settings` from `.env` + `config.yaml`
- Async I/O in API and dispatcher; CPU/GPU work in worker processes (not async)
- No global mutable state; pass dependencies via FastAPI `Depends`
- Every public function: docstring with Args / Returns / Raises
- Tests required for every `core/*` module; minimum 80% coverage on `core/` and `api/`
- Secrets only via env vars, never committed

---

## 12. Security & Compliance Checklist (must implement)

- JWT with short TTL + refresh; passwords hashed with bcrypt
- RBAC enforced at route level
- Rate limiting on `/auth/login` and `/search`
- CORS locked to configured origins
- Anti-spoofing on every new track before identity is committed
- Audit log for every write
- Configurable retention; GDPR purge job
- Signed webhook payloads (HMAC-SHA256)
- TLS termination assumed at ingress; HSTS headers in API
- No PII in logs

---

## 13. Acceptance Criteria (must all pass before "done")

- `docker compose up` brings up: postgres+pgvector, redis, mqtt, api, worker, dashboard, prometheus, grafana
- Seed script enrolls 5 demo identities from sample photos
- Synthetic RTSP source (looping mp4) produces live events visible in the dashboard within 2 s of start
- Watchlist hit triggers a red toast in the dashboard, an MQTT message, and a webhook POST
- `pytest` is green
- `tests/bench_pipeline.py` prints latency/throughput meeting §4 targets on the target GPU
- `mypy --strict` and `ruff` clean
- OpenAPI docs render at `/docs`
- README contains: architecture diagram (ASCII), quickstart, env vars, model download instructions, troubleshooting

---

## 14. What to do right now

Acknowledge the brief in **two sentences**, then begin **Phase 1**. For Phase 1, output:
1. The Phase-1 file tree
2. Every Phase-1 file in full
3. Exact run commands (`make ...` / `docker compose ...` / `pytest ...`)
4. A short changelog

Do not skip ahead. Wait for "next phase" before starting Phase 2.
