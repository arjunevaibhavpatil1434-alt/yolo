"""
AI Detection Module
Uses YOLOv8 for person and object detection, OpenCV for motion detection.
"""
import cv2
import numpy as np
import os
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple

logger = logging.getLogger(__name__)

SNAPSHOTS_DIR = Path(os.getenv("SNAPSHOTS_DIR", "/app/snapshots"))
SNAPSHOTS_DIR.mkdir(parents=True, exist_ok=True)

# YOLO model path — will auto-download yolov8n.pt on first run
YOLO_MODEL = os.getenv("YOLO_MODEL", "yolov8n.pt")

# YOLO class IDs we care about
PERSON_CLASS_ID = 0  # COCO class 0 = person

# Detection confidence threshold
CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", "0.4"))


class MotionDetector:
    """
    Frame-differencing motion detector.
    Lightweight — runs entirely in OpenCV without GPU.
    """

    def __init__(self, sensitivity: float = 0.5, min_area: int = 5000):
        self.sensitivity = sensitivity
        self.min_area = min_area
        self._background: Optional[np.ndarray] = None
        self._kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))

    def detect(self, frame: np.ndarray) -> Tuple[bool, float, List[Tuple[int, int, int, int]]]:
        """
        Detect motion in a frame.
        Returns (motion_detected, confidence, bounding_boxes)
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)

        if self._background is None:
            self._background = gray
            return False, 0.0, []

        # Compute absolute difference from background
        diff = cv2.absdiff(self._background, gray)
        _, thresh = cv2.threshold(diff, int(25 * (1 - self.sensitivity)), 255, cv2.THRESH_BINARY)
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, self._kernel)

        # Update background with exponential moving average
        self._background = cv2.addWeighted(self._background, 0.95, gray, 0.05, 0)

        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        boxes = []
        motion_area = 0

        for contour in contours:
            area = cv2.contourArea(contour)
            if area < self.min_area:
                continue
            x, y, w, h = cv2.boundingRect(contour)
            boxes.append((x, y, w, h))
            motion_area += area

        if not boxes:
            return False, 0.0, []

        total_area = frame.shape[0] * frame.shape[1]
        confidence = min(1.0, motion_area / (total_area * 0.1))
        return True, confidence, boxes


class YOLODetector:
    """
    YOLOv8-based person and face detector.
    Uses Ultralytics YOLO — downloads model weights on first run.
    """

    def __init__(self, model_path: str = YOLO_MODEL):
        self.model = None
        self.model_path = model_path
        self._load_model()

    def _load_model(self):
        try:
            from ultralytics import YOLO
            logger.info(f"Loading YOLO model: {self.model_path}")
            self.model = YOLO(self.model_path)
            logger.info("YOLO model loaded successfully")
        except ImportError:
            logger.warning("ultralytics not installed — YOLO detection disabled. Install: pip install ultralytics")
        except Exception as e:
            logger.error(f"Failed to load YOLO model: {e}")

    def detect_persons(
        self, frame: np.ndarray, confidence: float = CONFIDENCE_THRESHOLD
    ) -> List[Dict[str, Any]]:
        """
        Run YOLO inference and return list of person detections.
        Each detection: { confidence, bbox: [x1, y1, x2, y2] }
        """
        if self.model is None:
            return []

        try:
            results = self.model(frame, verbose=False, conf=confidence, classes=[PERSON_CLASS_ID])
            detections = []
            for result in results:
                for box in result.boxes:
                    if int(box.cls[0]) == PERSON_CLASS_ID:
                        detections.append({
                            "confidence": float(box.conf[0]),
                            "bbox": [int(x) for x in box.xyxy[0].tolist()],
                        })
            return detections
        except Exception as e:
            logger.error(f"YOLO inference error: {e}")
            return []


class FaceDetector:
    """
    OpenCV Haar Cascade face detector.
    Approximation — for production use a dedicated face recognition model.
    """

    def __init__(self):
        cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        self.face_cascade = cv2.CascadeClassifier(cascade_path)
        if self.face_cascade.empty():
            logger.warning("Haar cascade not loaded — face detection unavailable")

    def detect(self, frame: np.ndarray) -> List[Dict[str, Any]]:
        """Returns list of face detections: { confidence, bbox: [x, y, w, h] }"""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        return [
            {"confidence": 0.75, "bbox": [int(x), int(y), int(x + w), int(y + h)]}
            for (x, y, w, h) in faces
        ]


def save_snapshot(frame: np.ndarray, camera_id: int, event_type: str) -> str:
    """Save a frame as a snapshot image and return the relative path."""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    filename = f"{event_type}_cam{camera_id}_{ts}.jpg"
    filepath = SNAPSHOTS_DIR / filename
    cv2.imwrite(str(filepath), frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return f"/snapshots/{filename}"


def draw_annotations(
    frame: np.ndarray,
    detections: List[Dict[str, Any]],
    label: str,
    color: Tuple[int, int, int],
) -> np.ndarray:
    """Draw bounding boxes and labels on a frame (for debugging/snapshots)."""
    annotated = frame.copy()
    for det in detections:
        if "bbox" in det:
            b = det["bbox"]
            if len(b) == 4:
                x1, y1, x2, y2 = b
                cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
                cv2.putText(
                    annotated, f"{label} {det['confidence']:.0%}",
                    (x1, y1 - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1
                )
    return annotated
