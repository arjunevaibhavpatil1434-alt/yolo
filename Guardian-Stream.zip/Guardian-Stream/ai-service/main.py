"""
SentinelView AI Detection Service — with Face Recognition
Polls cameras, runs YOLO person detection, motion detection,
and InsightFace ArcFace recognition matched against the known-persons database.
"""
import asyncio
import aiohttp
import cv2
import os
import logging
import time
from pathlib import Path
from typing import Optional, Dict, List, Tuple, Any

from detector import MotionDetector, YOLODetector, save_snapshot, draw_annotations
from face_recognizer import InsightFaceRecognizer, HaarFaceDetector, EmbeddingCache, annotate_frame, embedding_to_list

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("ai-service")

# ── Configuration ─────────────────────────────────────────────────────────────
BACKEND_URL       = os.getenv("BACKEND_URL", "http://backend:8000")
POLL_INTERVAL     = float(os.getenv("POLL_INTERVAL", "2"))
CAMERAS_REFRESH   = float(os.getenv("CAMERAS_REFRESH", "30"))
AI_SECRET         = os.getenv("AI_SECRET", "internal-ai-service")
ENABLE_MOTION     = os.getenv("ENABLE_MOTION", "true").lower() == "true"
ENABLE_PERSON     = os.getenv("ENABLE_PERSON", "true").lower() == "true"
ENABLE_FACE       = os.getenv("ENABLE_FACE", "true").lower() == "true"

# Process every Nth frame for recognition (1 = every frame, 3 = every 3rd)
FACE_EVERY_N_FRAMES = int(os.getenv("FACE_EVERY_N_FRAMES", "2"))

# Enroll embeddings for face photos that the AI service hasn't processed yet
ENROLL_INTERVAL = float(os.getenv("ENROLL_INTERVAL", "60"))  # seconds


class CameraProcessor:
    def __init__(self, camera: dict):
        self.camera_id: int = camera["id"]
        self.rtsp_url: str = camera["rtsp_url"]
        self.camera_name: str = camera["name"]
        self.cap: Optional[cv2.VideoCapture] = None
        self.motion_detector = MotionDetector()
        self.last_event_time: dict = {}
        self.frame_count: int = 0

    def open_stream(self) -> bool:
        self.cap = cv2.VideoCapture(self.rtsp_url)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        if not self.cap.isOpened():
            logger.error(f"Camera {self.camera_id}: failed to open {self.rtsp_url}")
            return False
        logger.info(f"Camera {self.camera_id} ({self.camera_name}): stream opened")
        return True

    def read_frame(self) -> Optional[Any]:
        if not self.cap or not self.cap.isOpened():
            return None
        for _ in range(3):
            self.cap.grab()
        ret, frame = self.cap.retrieve()
        return frame if ret else None

    def close(self):
        if self.cap:
            self.cap.release()
            self.cap = None

    def can_emit(self, event_type: str, cooldown: float = 8.0) -> bool:
        now = time.time()
        if now - self.last_event_time.get(event_type, 0) >= cooldown:
            self.last_event_time[event_type] = now
            return True
        return False


async def post_event(
    session: aiohttp.ClientSession,
    camera_id: int,
    event_type: str,
    confidence: float,
    image_path: Optional[str] = None,
    metadata: Optional[dict] = None,
) -> None:
    payload = {
        "type": event_type,
        "camera_id": camera_id,
        "confidence": round(confidence, 3),
        "image_path": image_path,
        "metadata": metadata or {},
    }
    try:
        async with session.post(
            f"{BACKEND_URL}/events/",
            json=payload,
            headers={"X-AI-Secret": AI_SECRET},
            timeout=aiohttp.ClientTimeout(total=5),
        ) as resp:
            if resp.status not in (200, 201):
                logger.warning(f"Event post {resp.status}: {await resp.text()}")
    except Exception as e:
        logger.debug(f"Event post failed: {e}")


async def fetch_cameras(session: aiohttp.ClientSession) -> list:
    try:
        async with session.get(
            f"{BACKEND_URL}/cameras/",
            headers={"X-AI-Secret": AI_SECRET},
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            if resp.status == 200:
                cameras = await resp.json()
                return [c for c in cameras if c.get("status") != "offline"]
    except Exception as e:
        logger.warning(f"Camera fetch failed: {e}")
    return []


async def enroll_pending_faces(session: aiohttp.ClientSession, recognizer: InsightFaceRecognizer) -> None:
    """
    Find face records without embeddings and extract them using the AI model.
    This ensures faces uploaded via the web UI get their embeddings filled in.
    """
    try:
        async with session.get(
            f"{BACKEND_URL}/persons/embeddings",
            headers={"X-AI-Secret": AI_SECRET},
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            if resp.status != 200:
                return
            rows = await resp.json()

        # Find faces with no embedding
        pending = [r for r in rows if r.get("embedding") is None]
        if not pending:
            return

        logger.info(f"Enrolling {len(pending)} pending face(s) without embeddings…")

        for row in pending:
            face_id = row["face_id"]
            # We need the image path — fetch person detail
            person_id = row["person_id"]
            try:
                async with session.get(
                    f"{BACKEND_URL}/persons/{person_id}",
                    headers={"X-AI-Secret": AI_SECRET},
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as presp:
                    if presp.status != 200:
                        continue
                    person_data = await presp.json()

                # Find this face in the person's face list
                face_rec = next((f for f in person_data.get("faces", []) if f["id"] == face_id), None)
                if not face_rec:
                    continue

                image_url = face_rec["image_path"]
                # Download the image
                async with session.get(
                    f"{BACKEND_URL}{image_url}" if image_url.startswith("/api") else f"http://localhost{image_url}",
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as img_resp:
                    if img_resp.status != 200:
                        continue
                    img_data = await img_resp.read()

                import numpy as np
                img_arr = np.frombuffer(img_data, np.uint8)
                frame = cv2.imdecode(img_arr, cv2.IMREAD_COLOR)
                if frame is None:
                    continue

                faces = recognizer.detect_and_embed(frame)
                if not faces:
                    logger.warning(f"No face detected in face_id={face_id}")
                    continue

                # Take the highest-confidence face
                best = max(faces, key=lambda f: f["det_score"])
                emb = embedding_to_list(best["embedding"])

                # Write embedding back to backend
                async with session.post(
                    f"{BACKEND_URL}/persons/faces/{face_id}/embedding",
                    json={"embedding": emb},
                    headers={"X-AI-Secret": AI_SECRET},
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as wresp:
                    if wresp.status == 200:
                        logger.info(f"Enrolled embedding for face_id={face_id} ({row['person_name']})")
            except Exception as e:
                logger.warning(f"Enrollment failed for face_id={face_id}: {e}")
    except Exception as e:
        logger.warning(f"Pending face enrollment error: {e}")


async def process_camera(
    proc: CameraProcessor,
    yolo: YOLODetector,
    face_recognizer: InsightFaceRecognizer,
    fallback_detector: HaarFaceDetector,
    embed_cache: EmbeddingCache,
    session: aiohttp.ClientSession,
) -> None:
    frame = proc.read_frame()
    if frame is None:
        return

    proc.frame_count += 1
    tasks = []

    # ── Motion detection ──────────────────────────────────────────────────────
    if ENABLE_MOTION:
        motion, motion_conf, _ = proc.motion_detector.detect(frame)
        if motion and proc.can_emit("motion", cooldown=5.0):
            snap = save_snapshot(frame, proc.camera_id, "motion")
            tasks.append(post_event(session, proc.camera_id, "motion", motion_conf, snap))

    # ── Person detection (YOLO) ───────────────────────────────────────────────
    if ENABLE_PERSON:
        persons = yolo.detect_persons(frame)
        if persons and proc.can_emit("person", cooldown=10.0):
            annotated = draw_annotations(frame, persons, "person", (0, 120, 255))
            snap = save_snapshot(annotated, proc.camera_id, "person")
            tasks.append(post_event(
                session, proc.camera_id, "person",
                max(p["confidence"] for p in persons), snap,
                {"count": len(persons), "detections": persons[:5]},
            ))

    # ── Face recognition (every FACE_EVERY_N_FRAMES frames) ──────────────────
    if ENABLE_FACE and proc.frame_count % FACE_EVERY_N_FRAMES == 0:
        # Refresh embedding cache if stale
        await embed_cache.maybe_refresh(session)

        # Detect faces + extract embeddings
        face_data = face_recognizer.detect_and_embed(frame)
        if not face_data:
            # Fallback to Haar cascade (no embedding)
            face_data = fallback_detector.detect_and_embed(frame)

        if face_data:
            # Match each detected face against known persons
            matches: List[Tuple[Optional[int], Optional[str], float]] = []
            for face in face_data:
                if face["embedding"] is not None:
                    pid, pname, sim = await embed_cache.find_match(face["embedding"])
                    matches.append((pid, pname, sim))
                else:
                    matches.append((None, None, 0.75))

            # Determine if any known person was recognized
            known_matches = [(pid, pname, sim) for pid, pname, sim in matches if pid is not None]
            unknown_count = sum(1 for pid, _, _ in matches if pid is None)

            annotated = annotate_frame(frame, face_data, matches)
            snap = save_snapshot(annotated, proc.camera_id, "face")

            if known_matches and proc.can_emit("face_known", cooldown=15.0):
                # Emit one event per unique recognized person
                seen_ids: set = set()
                for pid, pname, sim in known_matches:
                    if pid not in seen_ids:
                        seen_ids.add(pid)
                        tasks.append(post_event(
                            session, proc.camera_id, "face", sim, snap,
                            {
                                "recognized": True,
                                "person_id": pid,
                                "person_name": pname,
                                "similarity": round(sim, 3),
                                "total_faces": len(face_data),
                                "unknown_faces": unknown_count,
                            },
                        ))
            elif unknown_count > 0 and proc.can_emit("face_unknown", cooldown=20.0):
                tasks.append(post_event(
                    session, proc.camera_id, "face", 0.75, snap,
                    {
                        "recognized": False,
                        "total_faces": len(face_data),
                        "unknown_faces": unknown_count,
                    },
                ))

    if tasks:
        await asyncio.gather(*tasks)


async def main():
    logger.info("SentinelView AI Detection Service (with Face Recognition) starting…")

    yolo = YOLODetector()
    face_recognizer = InsightFaceRecognizer()
    fallback_detector = HaarFaceDetector()
    embed_cache = EmbeddingCache()

    if not face_recognizer.load():
        logger.warning("InsightFace unavailable — falling back to Haar cascade (no recognition)")

    processors: Dict[int, CameraProcessor] = {}
    last_camera_refresh = 0.0
    last_enroll_run = 0.0

    async with aiohttp.ClientSession() as session:
        # Initial embedding cache load
        await embed_cache.refresh(session)

        while True:
            now = time.time()

            # Refresh camera list
            if now - last_camera_refresh >= CAMERAS_REFRESH:
                cameras = await fetch_cameras(session)
                camera_ids = {c["id"] for c in cameras}

                for cid in list(processors):
                    if cid not in camera_ids:
                        processors[cid].close()
                        del processors[cid]

                for cam in cameras:
                    if cam["id"] not in processors:
                        proc = CameraProcessor(cam)
                        if proc.open_stream():
                            processors[cam["id"]] = proc

                last_camera_refresh = now

            # Enroll pending face embeddings (photos without embeddings)
            if now - last_enroll_run >= ENROLL_INTERVAL:
                asyncio.ensure_future(
                    enroll_pending_faces(session, face_recognizer)
                )
                last_enroll_run = now

            # Process all active cameras concurrently
            if processors:
                await asyncio.gather(*[
                    process_camera(proc, yolo, face_recognizer, fallback_detector, embed_cache, session)
                    for proc in processors.values()
                ])

            await asyncio.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    asyncio.run(main())
