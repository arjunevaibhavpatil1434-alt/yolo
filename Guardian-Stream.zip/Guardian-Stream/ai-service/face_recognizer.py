"""
High-accuracy, low-latency face recognition using InsightFace (ArcFace).

Architecture:
  Detection:    RetinaFace (ONNX) — sub-millisecond on CPU for 720p frames
  Recognition:  ArcFace buffalo_l / buffalo_s (ONNX) — 512-dim embedding
  Matching:     Cosine similarity against in-memory embedding cache
  Accuracy:     ~99.8% on LFW benchmark (buffalo_l) / ~99.2% (buffalo_s)

The embeddings cache is updated every CACHE_REFRESH_SECONDS from the backend API.
This means recognition works entirely in memory — zero DB latency on the hot path.
"""
import asyncio
import aiohttp
import logging
import os
import time
import json
import base64
from typing import Optional, List, Dict, Tuple, Any
from pathlib import Path

import numpy as np
import cv2

logger = logging.getLogger("face_recognizer")

# ── Configuration ─────────────────────────────────────────────────────────────
BACKEND_URL = os.getenv("BACKEND_URL", "http://backend:8000")
AI_SECRET   = os.getenv("AI_SECRET", "internal-ai-service")
CACHE_REFRESH_SECONDS = float(os.getenv("FACE_CACHE_REFRESH", "30"))

# Cosine similarity threshold for a positive match
# 0.45 → high recall (more matches, some false positives)
# 0.55 → high precision (fewer matches, fewer false positives)
MATCH_THRESHOLD = float(os.getenv("FACE_MATCH_THRESHOLD", "0.50"))

# Max faces to process per frame (avoid overload on crowded scenes)
MAX_FACES_PER_FRAME = int(os.getenv("MAX_FACES_PER_FRAME", "10"))

# Use smaller/faster model for CPU-only environments
MODEL_NAME = os.getenv("INSIGHTFACE_MODEL", "buffalo_s")  # buffalo_l for GPU


# ── InsightFace loader ─────────────────────────────────────────────────────────

class InsightFaceRecognizer:
    """
    Wraps InsightFace FaceAnalysis for detection + recognition in one call.
    Lazy-initialised to avoid import errors when the package is missing.
    """
    def __init__(self, model_name: str = MODEL_NAME):
        self._app = None
        self._model_name = model_name
        self._ready = False

    def load(self) -> bool:
        try:
            import insightface
            from insightface.app import FaceAnalysis
            self._app = FaceAnalysis(
                name=self._model_name,
                allowed_modules=["detection", "recognition"],
                providers=["CUDAExecutionProvider", "CPUExecutionProvider"],
            )
            # ctx_id=-1 → CPU; 0 → first GPU
            self._app.prepare(ctx_id=-1, det_size=(640, 640))
            self._ready = True
            logger.info(f"InsightFace ({self._model_name}) loaded — ready")
            return True
        except ImportError:
            logger.warning(
                "insightface not installed. Run: pip install insightface onnxruntime"
            )
            return False
        except Exception as e:
            logger.error(f"InsightFace load failed: {e}")
            return False

    def detect_and_embed(self, frame: np.ndarray) -> List[Dict[str, Any]]:
        """
        Run face detection + embedding extraction on a BGR frame.
        Returns list of dicts: {bbox, embedding, det_score, kps}
        """
        if not self._ready or self._app is None:
            return []
        try:
            faces = self._app.get(frame)
            results = []
            for face in faces[:MAX_FACES_PER_FRAME]:
                emb = face.embedding  # shape (512,) normalized L2 vector
                bbox = face.bbox.astype(int).tolist()  # [x1, y1, x2, y2]
                results.append({
                    "bbox": bbox,
                    "embedding": emb,
                    "det_score": float(face.det_score),
                    "kps": face.kps.tolist() if face.kps is not None else [],
                })
            return results
        except Exception as e:
            logger.debug(f"Face detection error: {e}")
            return []


# ── Fallback: OpenCV Haar Cascade ────────────────────────────────────────────

class HaarFaceDetector:
    """CPU-only fallback when InsightFace is unavailable."""
    def __init__(self):
        cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        self._cascade = cv2.CascadeClassifier(cascade_path)
        if self._cascade.empty():
            logger.warning("Haar cascade not loaded")

    def detect_and_embed(self, frame: np.ndarray) -> List[Dict[str, Any]]:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self._cascade.detectMultiScale(
            gray, scaleFactor=1.1, minNeighbors=5, minSize=(60, 60)
        )
        return [
            {
                "bbox": [int(x), int(y), int(x + w), int(y + h)],
                "embedding": None,     # no embedding from Haar
                "det_score": 0.75,
                "kps": [],
            }
            for (x, y, w, h) in faces
        ]


# ── In-memory embedding cache ─────────────────────────────────────────────────

class EmbeddingCache:
    """
    Keeps known-person embeddings in memory as a (N, 512) numpy matrix.
    Matching is a single matrix multiply — O(N) but extremely fast.
    """
    def __init__(self):
        self._lock = asyncio.Lock()
        self._embeddings: Optional[np.ndarray] = None  # shape (N, 512)
        self._person_ids: List[int] = []
        self._person_names: List[str] = []
        self._face_ids: List[int] = []
        self._last_refresh: float = 0.0
        self._count: int = 0

    @property
    def count(self) -> int:
        return self._count

    def cosine_similarity_batch(self, query: np.ndarray) -> Optional[np.ndarray]:
        """Compute cosine similarity between query (512,) and all known embeddings."""
        if self._embeddings is None or self._count == 0:
            return None
        # Both query and DB embeddings are already L2-normalised by InsightFace
        return self._embeddings @ query  # shape (N,)

    async def refresh(self, session: aiohttp.ClientSession) -> None:
        """Fetch all face embeddings from the backend and rebuild the matrix."""
        try:
            async with session.get(
                f"{BACKEND_URL}/persons/embeddings",
                headers={"X-AI-Secret": AI_SECRET},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                if resp.status != 200:
                    logger.warning(f"Embedding refresh got {resp.status}")
                    return
                data = await resp.json()

            ids, names, face_ids, embeddings = [], [], [], []
            for row in data:
                emb = row.get("embedding")
                if emb is None:
                    continue
                arr = np.array(emb, dtype=np.float32)
                if arr.shape != (512,):
                    continue
                # Normalise (should already be normalised, but be safe)
                norm = np.linalg.norm(arr)
                if norm > 0:
                    arr /= norm
                ids.append(row["person_id"])
                names.append(row["person_name"])
                face_ids.append(row["face_id"])
                embeddings.append(arr)

            async with self._lock:
                if embeddings:
                    self._embeddings = np.stack(embeddings)  # (N, 512)
                else:
                    self._embeddings = None
                self._person_ids = ids
                self._person_names = names
                self._face_ids = face_ids
                self._count = len(ids)
                self._last_refresh = time.time()

            logger.info(f"Embedding cache refreshed: {self._count} faces")
        except Exception as e:
            logger.warning(f"Embedding cache refresh failed: {e}")

    async def maybe_refresh(self, session: aiohttp.ClientSession) -> None:
        if time.time() - self._last_refresh >= CACHE_REFRESH_SECONDS:
            await self.refresh(session)

    async def find_match(
        self, embedding: np.ndarray
    ) -> Tuple[Optional[int], Optional[str], float]:
        """
        Find the best matching known person.
        Returns (person_id, person_name, similarity) or (None, None, 0.0)
        """
        async with self._lock:
            similarities = self.cosine_similarity_batch(embedding)

        if similarities is None:
            return None, None, 0.0

        best_idx = int(np.argmax(similarities))
        best_sim = float(similarities[best_idx])

        if best_sim >= MATCH_THRESHOLD:
            return self._person_ids[best_idx], self._person_names[best_idx], best_sim

        return None, None, best_sim


# ── Frame annotator ───────────────────────────────────────────────────────────

def annotate_frame(
    frame: np.ndarray,
    faces: List[Dict[str, Any]],
    matches: List[Tuple[Optional[int], Optional[str], float]],
) -> np.ndarray:
    """Draw bounding boxes and identity labels on a frame (for snapshot saving)."""
    annotated = frame.copy()
    for face, (pid, name, sim) in zip(faces, matches):
        bbox = face["bbox"]
        x1, y1, x2, y2 = bbox

        if pid is not None:
            color = (0, 220, 100)   # green — known person
            label = f"{name} ({sim:.0%})"
        else:
            color = (0, 120, 255)   # orange — unknown face
            label = f"Unknown ({face['det_score']:.0%})"

        cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
        # Label background
        (lw, lh), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        cv2.rectangle(annotated, (x1, y1 - lh - 8), (x1 + lw + 4, y1), color, -1)
        cv2.putText(
            annotated, label, (x1 + 2, y1 - 4),
            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1,
        )
    return annotated


# ── Embedding serialization helpers ──────────────────────────────────────────

def embedding_to_list(emb: np.ndarray) -> List[float]:
    """Convert numpy embedding to JSON-serializable list."""
    return emb.tolist()


def list_to_embedding(lst: List[float]) -> np.ndarray:
    """Convert stored list back to numpy array."""
    return np.array(lst, dtype=np.float32)
