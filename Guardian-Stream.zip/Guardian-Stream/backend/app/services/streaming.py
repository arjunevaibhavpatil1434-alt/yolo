"""
FFmpeg streaming service.
Manages RTSP → HLS conversion and segment-based recording.
"""
import asyncio
import os
import logging
import shutil
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)

STREAMS_DIR = Path(os.getenv("STREAMS_DIR", "/app/streams"))
RECORDINGS_DIR = Path(os.getenv("RECORDINGS_DIR", "/app/recordings"))

# Track active FFmpeg processes per camera
_processes: Dict[int, asyncio.subprocess.Process] = {}


def get_hls_url(camera_id: int, base_url: str) -> str:
    """Return the HLS playlist URL for a camera."""
    return f"{base_url}/streams/camera_{camera_id}/playlist.m3u8"


def build_ffmpeg_command(
    rtsp_url: str,
    camera_id: int,
    segment_duration: int = 4,
    hls_list_size: int = 10,
    record: bool = True,
) -> list[str]:
    """
    Build FFmpeg command for RTSP → HLS conversion with optional recording.

    Args:
        rtsp_url: Source RTSP stream URL
        camera_id: Camera ID (used to name output directories)
        segment_duration: HLS segment length in seconds
        hls_list_size: Number of segments to keep in the playlist (0 = keep all for recording)
        record: Whether to also save a continuous MP4 recording

    Returns:
        FFmpeg command as a list of strings
    """
    stream_dir = STREAMS_DIR / f"camera_{camera_id}"
    stream_dir.mkdir(parents=True, exist_ok=True)

    playlist = str(stream_dir / "playlist.m3u8")
    segment_pattern = str(stream_dir / "seg_%03d.ts")

    cmd = [
        "ffmpeg",
        "-loglevel", "warning",
        "-rtsp_transport", "tcp",          # Use TCP for reliability
        "-i", rtsp_url,
        "-c:v", "libx264",                 # Re-encode to H.264 for broad HLS support
        "-preset", "veryfast",             # Balance quality/CPU
        "-tune", "zerolatency",            # Minimize latency
        "-c:a", "aac",
        "-b:a", "128k",
        "-f", "hls",
        "-hls_time", str(segment_duration),
        "-hls_list_size", str(hls_list_size),
        "-hls_flags", "delete_segments+append_list",
        "-hls_segment_filename", segment_pattern,
        playlist,
    ]

    if record:
        rec_dir = RECORDINGS_DIR / f"camera_{camera_id}"
        rec_dir.mkdir(parents=True, exist_ok=True)
        rec_file = str(rec_dir / "recording_%Y%m%d_%H%M%S.mp4")
        # Tee output to also save a recording
        cmd = [
            "ffmpeg",
            "-loglevel", "warning",
            "-rtsp_transport", "tcp",
            "-i", rtsp_url,
            # HLS output
            "-map", "0",
            "-c:v", "libx264", "-preset", "veryfast", "-tune", "zerolatency",
            "-c:a", "aac", "-b:a", "128k",
            "-f", "hls",
            "-hls_time", str(segment_duration),
            "-hls_list_size", str(hls_list_size),
            "-hls_flags", "delete_segments+append_list",
            "-hls_segment_filename", segment_pattern,
            playlist,
            # MP4 recording output
            "-map", "0",
            "-c:v", "copy", "-c:a", "copy",
            "-f", "segment",
            "-segment_time", "300",          # 5-minute recording segments
            "-segment_format", "mp4",
            "-reset_timestamps", "1",
            "-strftime", "1",
            str(rec_dir / "seg_%Y%m%d_%H%M%S.mp4"),
        ]

    return cmd


async def start_stream(camera_id: int, rtsp_url: str) -> bool:
    """Start an FFmpeg process for a camera. Returns True on success."""
    if camera_id in _processes:
        logger.warning(f"Camera {camera_id} stream already running")
        return True

    cmd = build_ffmpeg_command(rtsp_url, camera_id)
    logger.info(f"Starting stream for camera {camera_id}: {' '.join(cmd[:6])}...")

    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _processes[camera_id] = process
        logger.info(f"Camera {camera_id} stream started (PID {process.pid})")
        return True
    except FileNotFoundError:
        logger.error("FFmpeg not found. Install ffmpeg to enable streaming.")
        return False
    except Exception as e:
        logger.error(f"Failed to start stream for camera {camera_id}: {e}")
        return False


async def stop_stream(camera_id: int) -> None:
    """Stop the FFmpeg process for a camera."""
    process = _processes.pop(camera_id, None)
    if process:
        process.terminate()
        try:
            await asyncio.wait_for(process.wait(), timeout=5)
        except asyncio.TimeoutError:
            process.kill()
        logger.info(f"Camera {camera_id} stream stopped")


# ── Example FFmpeg commands for documentation / manual use ───────────────────

EXAMPLE_SINGLE_CAMERA = """
# Single camera: RTSP → HLS (run in terminal)
ffmpeg \\
  -rtsp_transport tcp \\
  -i rtsp://admin:pass@192.168.1.100:554/stream \\
  -c:v libx264 -preset veryfast -tune zerolatency \\
  -c:a aac -b:a 128k \\
  -f hls \\
  -hls_time 4 -hls_list_size 10 \\
  -hls_flags delete_segments+append_list \\
  -hls_segment_filename /app/streams/camera_1/seg_%03d.ts \\
  /app/streams/camera_1/playlist.m3u8
"""

EXAMPLE_MULTI_CAMERA = """
# Multi-camera: run one FFmpeg process per camera (or use bash script)
for CAMERA_ID in 1 2 3 4 5; do
  RTSP_URL="rtsp://admin:pass@192.168.1.${CAMERA_ID}0:554/stream"
  mkdir -p /app/streams/camera_${CAMERA_ID}
  ffmpeg \\
    -rtsp_transport tcp \\
    -i "${RTSP_URL}" \\
    -c:v libx264 -preset veryfast -tune zerolatency \\
    -c:a aac -b:a 128k \\
    -f hls -hls_time 4 -hls_list_size 10 \\
    -hls_flags delete_segments+append_list \\
    -hls_segment_filename "/app/streams/camera_${CAMERA_ID}/seg_%03d.ts" \\
    "/app/streams/camera_${CAMERA_ID}/playlist.m3u8" &
done
wait
"""

EXAMPLE_TEST_RTSP = """
# Test RTSP source using FFmpeg's built-in test pattern (no camera needed)
ffmpeg \\
  -re \\
  -f lavfi -i "testsrc=size=1280x720:rate=25" \\
  -f lavfi -i "sine=frequency=1000:sample_rate=44100" \\
  -c:v libx264 -preset veryfast -tune zerolatency \\
  -c:a aac -b:a 128k \\
  -f rtsp \\
  rtsp://localhost:8554/test
# Point a camera's RTSP URL to rtsp://localhost:8554/test
"""
