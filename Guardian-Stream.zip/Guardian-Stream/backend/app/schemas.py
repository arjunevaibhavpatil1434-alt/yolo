"""
Pydantic schemas for request/response validation.
Mirrors the OpenAPI spec types exactly.
"""
from __future__ import annotations
from datetime import datetime
from typing import Optional, Any, List
from pydantic import BaseModel, ConfigDict


# ── Auth ──────────────────────────────────────────────────────────────────────

class LoginRequest(BaseModel):
    username: str
    password: str


class UserInfo(BaseModel):
    id: int
    username: str
    model_config = ConfigDict(from_attributes=True)


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserInfo


# ── Camera ────────────────────────────────────────────────────────────────────

class CameraBase(BaseModel):
    name: str
    rtsp_url: str
    location: str = ""


class CreateCameraBody(CameraBase):
    pass


class UpdateCameraBody(BaseModel):
    name: Optional[str] = None
    rtsp_url: Optional[str] = None
    location: Optional[str] = None
    status: Optional[str] = None


class Camera(CameraBase):
    id: int
    status: str
    stream_url: Optional[str] = None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


# ── Event ─────────────────────────────────────────────────────────────────────

class EventBase(BaseModel):
    type: str
    camera_id: int
    image_path: Optional[str] = None
    confidence: float = 0.0
    metadata: Optional[Any] = None


class CreateEventBody(EventBase):
    pass


class Event(BaseModel):
    id: int
    type: str
    camera_id: int
    camera_name: Optional[str] = None
    image_path: Optional[str] = None
    confidence: float
    timestamp: datetime
    metadata: Optional[Any] = None
    model_config = ConfigDict(from_attributes=True)


class EventsPage(BaseModel):
    items: List[Event]
    total: int
    limit: int
    offset: int


# ── Recording ─────────────────────────────────────────────────────────────────

class RecordingBase(BaseModel):
    camera_id: int
    file_path: str
    duration_seconds: int = 0
    file_size_mb: float = 0.0


class CreateRecordingBody(RecordingBase):
    pass


class Recording(BaseModel):
    id: int
    camera_id: int
    camera_name: Optional[str] = None
    file_path: str
    duration_seconds: int
    file_size_mb: float
    timestamp: datetime
    model_config = ConfigDict(from_attributes=True)


# ── Stats ─────────────────────────────────────────────────────────────────────

class DashboardStats(BaseModel):
    total_cameras: int
    online_cameras: int
    offline_cameras: int
    total_events_today: int
    person_detections_today: int
    motion_events_today: int
    face_detections_today: int
    total_recordings: int
    storage_used_gb: float


class HourlyEventCount(BaseModel):
    hour: str
    count: int
    type: str


class CameraEventCount(BaseModel):
    camera_id: int
    camera_name: str
    count: int
