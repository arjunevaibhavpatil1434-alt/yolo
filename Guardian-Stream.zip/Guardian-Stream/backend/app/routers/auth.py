"""Authentication router — login and token generation."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..database import get_db
from .. import models, schemas
from ..auth import hash_password, verify_password, create_access_token

router = APIRouter()


@router.post("/login", response_model=schemas.LoginResponse)
def login(request: schemas.LoginRequest, db: Session = Depends(get_db)):
    """Authenticate user and return JWT token."""
    user = db.query(models.User).filter(models.User.username == request.username).first()

    # Auto-create admin user on first run
    if not user and request.username == "admin" and request.password == "admin":
        user = models.User(
            username="admin",
            password_hash=hash_password("admin"),
        )
        db.add(user)
        db.commit()
        db.refresh(user)

    if not user or not verify_password(request.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    token = create_access_token(user.id, user.username)
    return schemas.LoginResponse(
        access_token=token,
        token_type="bearer",
        user=schemas.UserInfo(id=user.id, username=user.username),
    )
