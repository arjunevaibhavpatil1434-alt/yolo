"""Stats router — dashboard summary and analytics endpoints."""
from datetime import datetime, timezone, timedelta
from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..database import get_db
from .. import models, schemas
from ..auth import get_current_user

router = APIRouter()


@router.get("/summary", response_model=schemas.DashboardStats)
def get_dashboard_stats(
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)

    cameras = db.query(models.Camera.status).all()
    total_cameras = len(cameras)
    online_cameras = sum(1 for c in cameras if c.status == "online")
    offline_cameras = sum(1 for c in cameras if c.status == "offline")

    # Events today grouped by type
    events_today = (
        db.query(models.Event.type, func.count(models.Event.id).label("cnt"))
        .filter(models.Event.timestamp >= today_start)
        .group_by(models.Event.type)
        .all()
    )
    event_map = {e.type: e.cnt for e in events_today}
    total_events_today = sum(event_map.values())

    # Recordings summary
    rec_stats = db.query(
        func.count(models.Recording.id).label("cnt"),
        func.coalesce(func.sum(models.Recording.file_size_mb), 0).label("total_mb"),
    ).first()

    return schemas.DashboardStats(
        total_cameras=total_cameras,
        online_cameras=online_cameras,
        offline_cameras=offline_cameras,
        total_events_today=total_events_today,
        person_detections_today=event_map.get("person", 0),
        motion_events_today=event_map.get("motion", 0),
        face_detections_today=event_map.get("face", 0),
        total_recordings=rec_stats.cnt,
        storage_used_gb=float(rec_stats.total_mb) / 1024.0,
    )


@router.get("/events-by-hour", response_model=List[schemas.HourlyEventCount])
def get_events_by_hour(
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    since = datetime.now(timezone.utc) - timedelta(hours=24)

    rows = (
        db.query(
            func.strftime("%H:00", models.Event.timestamp).label("hour"),
            models.Event.type,
            func.count(models.Event.id).label("cnt"),
        )
        .filter(models.Event.timestamp >= since)
        .group_by("hour", models.Event.type)
        .order_by("hour")
        .all()
    )

    return [schemas.HourlyEventCount(hour=r.hour, type=r.type, count=r.cnt) for r in rows]


@router.get("/events-by-camera", response_model=List[schemas.CameraEventCount])
def get_events_by_camera(
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    rows = (
        db.query(
            models.Event.camera_id,
            models.Camera.name.label("camera_name"),
            func.count(models.Event.id).label("cnt"),
        )
        .join(models.Camera, models.Event.camera_id == models.Camera.id)
        .group_by(models.Event.camera_id, models.Camera.name)
        .order_by(func.count(models.Event.id).desc())
        .limit(10)
        .all()
    )

    return [
        schemas.CameraEventCount(camera_id=r.camera_id, camera_name=r.camera_name, count=r.cnt)
        for r in rows
    ]
