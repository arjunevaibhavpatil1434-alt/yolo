"""Camera CRUD router."""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..database import get_db
from .. import models, schemas
from ..auth import get_current_user

router = APIRouter()


@router.get("/", response_model=List[schemas.Camera])
def list_cameras(
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    return db.query(models.Camera).order_by(models.Camera.id).all()


@router.post("/", response_model=schemas.Camera, status_code=status.HTTP_201_CREATED)
def create_camera(
    body: schemas.CreateCameraBody,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    camera = models.Camera(**body.model_dump())
    db.add(camera)
    db.commit()
    db.refresh(camera)
    return camera


@router.get("/{camera_id}", response_model=schemas.Camera)
def get_camera(
    camera_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    camera = db.query(models.Camera).filter(models.Camera.id == camera_id).first()
    if not camera:
        raise HTTPException(status_code=404, detail="Camera not found")
    return camera


@router.put("/{camera_id}", response_model=schemas.Camera)
def update_camera(
    camera_id: int,
    body: schemas.UpdateCameraBody,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    camera = db.query(models.Camera).filter(models.Camera.id == camera_id).first()
    if not camera:
        raise HTTPException(status_code=404, detail="Camera not found")
    for field, value in body.model_dump(exclude_none=True).items():
        setattr(camera, field, value)
    db.commit()
    db.refresh(camera)
    return camera


@router.delete("/{camera_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_camera(
    camera_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    camera = db.query(models.Camera).filter(models.Camera.id == camera_id).first()
    if not camera:
        raise HTTPException(status_code=404, detail="Camera not found")
    db.delete(camera)
    db.commit()
