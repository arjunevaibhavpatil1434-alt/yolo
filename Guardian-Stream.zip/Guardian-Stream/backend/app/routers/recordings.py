"""Recordings router — list video recording segments."""
from typing import Optional, List
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from .. import models, schemas
from ..auth import get_current_user

router = APIRouter()


@router.get("/", response_model=List[schemas.Recording])
def list_recordings(
    camera_id: Optional[int] = Query(None),
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    query = db.query(models.Recording).options(joinedload(models.Recording.camera))

    if camera_id is not None:
        query = query.filter(models.Recording.camera_id == camera_id)

    recordings = query.order_by(models.Recording.timestamp.desc()).limit(limit).all()

    return [
        schemas.Recording(
            id=r.id,
            camera_id=r.camera_id,
            camera_name=r.camera.name if r.camera else None,
            file_path=r.file_path,
            duration_seconds=r.duration_seconds,
            file_size_mb=r.file_size_mb,
            timestamp=r.timestamp,
        )
        for r in recordings
    ]


@router.post("/", response_model=schemas.Recording, status_code=201, include_in_schema=False)
def create_recording(
    body: schemas.CreateRecordingBody,
    db: Session = Depends(get_db),
):
    """Internal endpoint called by the streaming service to register a completed segment."""
    rec = models.Recording(**body.model_dump())
    db.add(rec)
    db.commit()
    db.refresh(rec)
    return schemas.Recording(
        id=rec.id,
        camera_id=rec.camera_id,
        camera_name=None,
        file_path=rec.file_path,
        duration_seconds=rec.duration_seconds,
        file_size_mb=rec.file_size_mb,
        timestamp=rec.timestamp,
    )
