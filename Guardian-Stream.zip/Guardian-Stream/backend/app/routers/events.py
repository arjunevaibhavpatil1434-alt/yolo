"""Events router — list and retrieve AI detection events."""
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from .. import models, schemas
from ..auth import get_current_user

router = APIRouter()


def _event_to_schema(ev: models.Event) -> schemas.Event:
    return schemas.Event(
        id=ev.id,
        type=ev.type,
        camera_id=ev.camera_id,
        camera_name=ev.camera.name if ev.camera else None,
        image_path=ev.image_path,
        confidence=ev.confidence,
        timestamp=ev.timestamp,
        metadata=ev.metadata_,
    )


@router.get("/", response_model=schemas.EventsPage)
def list_events(
    camera_id: Optional[int] = Query(None),
    type: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    query = db.query(models.Event).options(joinedload(models.Event.camera))

    if camera_id is not None:
        query = query.filter(models.Event.camera_id == camera_id)
    if type is not None:
        query = query.filter(models.Event.type == type)

    total = query.count()
    events = query.order_by(models.Event.timestamp.desc()).offset(offset).limit(limit).all()

    return schemas.EventsPage(
        items=[_event_to_schema(e) for e in events],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get("/{event_id}", response_model=schemas.Event)
def get_event(
    event_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    ev = db.query(models.Event).options(joinedload(models.Event.camera)).filter(models.Event.id == event_id).first()
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    return _event_to_schema(ev)


@router.post("/", response_model=schemas.Event, status_code=201, include_in_schema=False)
def create_event(
    body: schemas.CreateEventBody,
    db: Session = Depends(get_db),
):
    """Internal endpoint called by the AI service to ingest detection events."""
    ev = models.Event(
        type=body.type,
        camera_id=body.camera_id,
        image_path=body.image_path,
        confidence=body.confidence,
        metadata_=body.metadata,
    )
    db.add(ev)
    db.commit()
    db.refresh(ev)
    ev_with_camera = db.query(models.Event).options(joinedload(models.Event.camera)).filter(models.Event.id == ev.id).first()
    return _event_to_schema(ev_with_camera)
