"""
SQLAlchemy ORM models.
Designed for easy migration from SQLite → PostgreSQL:
  - Use column types from sqlalchemy (String, Integer, Float, DateTime, JSON)
  - No SQLite-specific types
"""
from sqlalchemy import Column, Integer, String, Float, DateTime, JSON, ForeignKey
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    password_hash = Column(String(256), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Camera(Base):
    __tablename__ = "cameras"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(128), nullable=False)
    rtsp_url = Column(String(512), nullable=False)
    location = Column(String(256), nullable=False, default="")
    status = Column(String(32), nullable=False, default="offline")  # online | offline | recording
    stream_url = Column(String(512), nullable=True)  # HLS URL served by nginx/CDN
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    events = relationship("Event", back_populates="camera", cascade="all, delete-orphan")
    recordings = relationship("Recording", back_populates="camera", cascade="all, delete-orphan")


class Event(Base):
    __tablename__ = "events"

    id = Column(Integer, primary_key=True, index=True)
    type = Column(String(32), nullable=False)  # motion | person | face
    camera_id = Column(Integer, ForeignKey("cameras.id", ondelete="CASCADE"), nullable=False, index=True)
    image_path = Column(String(512), nullable=True)   # path to snapshot image
    confidence = Column(Float, nullable=False, default=0.0)
    metadata_ = Column("metadata", JSON, nullable=True)  # extra detection data (bounding boxes, etc.)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)

    camera = relationship("Camera", back_populates="events")


class Recording(Base):
    __tablename__ = "recordings"

    id = Column(Integer, primary_key=True, index=True)
    camera_id = Column(Integer, ForeignKey("cameras.id", ondelete="CASCADE"), nullable=False, index=True)
    file_path = Column(String(512), nullable=False)
    duration_seconds = Column(Integer, nullable=False, default=0)
    file_size_mb = Column(Float, nullable=False, default=0.0)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)

    camera = relationship("Camera", back_populates="recordings")
