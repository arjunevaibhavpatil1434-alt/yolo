"""
SentinelView FastAPI Backend
Main application entry point.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from .database import engine, Base
from .routers import auth, cameras, events, recordings, stats

# Create all tables on startup (SQLite auto-migration)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="SentinelView API",
    description="Live video surveillance system API",
    version="1.0.0",
)

# CORS — adjust origins in production via environment variable
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static file serving for snapshots and HLS streams
os.makedirs("/app/snapshots", exist_ok=True)
os.makedirs("/app/streams", exist_ok=True)
os.makedirs("/app/recordings", exist_ok=True)

app.mount("/snapshots", StaticFiles(directory="/app/snapshots"), name="snapshots")
app.mount("/streams", StaticFiles(directory="/app/streams"), name="streams")

# Register all routers
app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(cameras.router, prefix="/cameras", tags=["cameras"])
app.include_router(events.router, prefix="/events", tags=["events"])
app.include_router(recordings.router, prefix="/recordings", tags=["recordings"])
app.include_router(stats.router, prefix="/stats", tags=["stats"])


@app.get("/healthz", tags=["health"])
def health_check():
    return {"status": "ok"}
