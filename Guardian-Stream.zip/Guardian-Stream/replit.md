# SentinelView — Live Video Surveillance System

## Overview

Production-grade multi-camera video surveillance dashboard built as a pnpm monorepo,
with live AI detection (YOLO person detection, motion), ArcFace face recognition, and
a full face enrollment database backed by PostgreSQL.

## Architecture

```
artifacts/
  surveillance-ui/    — React + Vite frontend (dark theme, HLS.js video player)
  api-server/         — Node.js / Express API (JWT auth, Drizzle ORM, PostgreSQL)
backend/              — Python FastAPI backend (SQLite/SQLAlchemy, Docker target)
ai-service/           — Python AI detection service (YOLO v8, InsightFace ArcFace, motion)
nginx/                — Nginx reverse proxy config
lib/
  api-spec/           — OpenAPI 3.1 spec (source of truth)
  api-client-react/   — Orval-generated React Query hooks + custom fetch
  api-zod/            — Orval-generated Zod schemas
  db/                 — Drizzle ORM schema (users, cameras, events, recordings, persons)
docker-compose.yml    — Full Docker Compose stack
```

## Stack

- **Monorepo**: pnpm workspaces
- **Node.js**: 24, TypeScript 5.9
- **Frontend**: React 19, Vite 7, HLS.js, Recharts, Tailwind CSS, Lucide icons
- **Node API**: Express 5, Drizzle ORM, PostgreSQL, JWT (`jsonwebtoken`), multer (face uploads)
- **Python API**: FastAPI, SQLAlchemy, SQLite (dev) / PostgreSQL (prod)
- **AI Service**: YOLOv8 (ultralytics), InsightFace/ArcFace (buffalo_s/l), OpenCV, aiohttp
- **Streaming**: FFmpeg RTSP→HLS pipeline
- **Codegen**: Orval from OpenAPI spec

## Key Commands

```bash
pnpm run typecheck                              # Full typecheck all packages
pnpm run typecheck:libs                         # Rebuild lib declarations
pnpm --filter @workspace/api-spec run codegen  # Regenerate API hooks from OpenAPI
pnpm --filter @workspace/db run push           # Push DB schema (dev)
```

## Docker Deployment

```bash
cp backend/.env.example backend/.env   # Edit secrets
docker compose up --build -d           # Start full stack
# App available at http://localhost:80
```

## Default Credentials

- **Username**: `admin`
- **Password**: `admin`

## Authentication

- Password hashing: SHA-256 with fixed salt `sentinel-pw-salt-v1`
- JWT tokens stored in `localStorage` as `sentinel_token`; signed with `SESSION_SECRET` env var
- All API routes require `Authorization: Bearer <token>` except `/api/auth/login`

## Database Schema (PostgreSQL / Drizzle)

- `users` — operator accounts with hashed passwords
- `cameras` — RTSP camera registry with status + HLS stream URL
- `events` — AI detection events (motion, person, face) with confidence scores + person_id/name
- `recordings` — Video recording segment metadata
- `known_persons` — Face enrollment records (name, notes, face_count, thumbnail_path)
- `person_faces` — Individual face photos per person with 512-dim ArcFace embedding (JSONB)

## API Routes

All routes under `/api`:
- `POST /api/auth/login` — JWT authentication
- `GET/POST/PUT/DELETE /api/cameras` — Camera CRUD
- `GET /api/events` — Paginated events with camera/type filters
- `GET /api/recordings` — Recording segments
- `GET /api/stats/summary` — Dashboard KPIs
- `GET /api/stats/events-by-hour` — 24h event chart data
- `GET /api/stats/events-by-camera` — Per-camera event counts
- `GET/POST /api/persons` — List / create known persons
- `GET/PUT/DELETE /api/persons/:id` — Person detail CRUD
- `POST /api/persons/:id/enroll` — Upload face photo (multipart, triggers AI embedding)
- `DELETE /api/persons/:id/faces/:faceId` — Remove face sample
- `GET /api/persons/embeddings` — Internal: all ArcFace embeddings for AI cache
- `POST /api/persons/faces/:faceId/embedding` — Internal: AI service writes embedding back
- `GET /api/faces/:filename` — Serve uploaded face images (static)

## Face Recognition Flow

1. Operator uploads face photo via **Known Persons** page (`/persons`)
2. Express saves image to `FACES_DIR` (`public/faces/`), inserts `person_faces` row (embedding=null)
3. Python AI service polls `/api/persons/embeddings` every 60 s; finds null-embedding rows
4. AI service downloads the image, runs InsightFace RetinaFace detection + ArcFace embedding
5. Writes the 512-dim embedding back via `POST /api/persons/faces/:faceId/embedding`
6. In-memory `EmbeddingCache` in the AI service refreshes periodically; uses cosine similarity (threshold 0.50) to match live camera frames against all enrolled persons
7. Recognized faces emit `face` events with `person_id` and `person_name` metadata

## FFmpeg Streaming (Docker)

Each camera runs its own FFmpeg process converting RTSP → HLS:
```bash
ffmpeg -rtsp_transport tcp -i rtsp://... \
  -c:v libx264 -preset veryfast -tune zerolatency \
  -f hls -hls_time 4 -hls_list_size 10 \
  /app/streams/camera_1/playlist.m3u8
```

## AI Detection (Docker)

- **Motion**: Frame-differencing per camera, 5 s cooldown
- **Person**: YOLOv8 bounding-box detection, 10 s cooldown
- **Face**: InsightFace ArcFace (buffalo_s model), every 2nd frame, 15 s cooldown for known / 20 s for unknown
- Haar cascade fallback when InsightFace unavailable
- All events posted to `/events/` with confidence score + optional snapshot image
