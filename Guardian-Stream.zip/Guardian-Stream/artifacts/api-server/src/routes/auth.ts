import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import crypto from "crypto";
import jwt from "jsonwebtoken";

const router = Router();

// JWT signing uses the session secret; password hashing uses its own fixed salt
// so that stored hashes never break across restarts or secret rotations.
const JWT_SECRET = process.env.SESSION_SECRET || "surveillance-dev-secret-change-in-production";
const PW_SALT = "sentinel-pw-salt-v1";

function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(PW_SALT + password).digest("hex");
}

function createToken(userId: number, username: string): string {
  return jwt.sign({ sub: userId, username }, JWT_SECRET, { expiresIn: "24h" });
}

router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: "Username and password required" });
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.username, username)).limit(1);

  if (!user) {
    // Auto-create admin user on first login if it doesn't exist
    if (username === "admin" && password === "admin") {
      const [newUser] = await db.insert(usersTable).values({
        username: "admin",
        password_hash: hashPassword("admin"),
      }).returning();
      const token = createToken(newUser.id, newUser.username);
      return res.json({ access_token: token, token_type: "bearer", user: { id: newUser.id, username: newUser.username } });
    }
    return res.status(401).json({ error: "Invalid credentials" });
  }

  if (user.password_hash !== hashPassword(password)) {
    return res.status(401).json({ error: "Invalid credentials" });
  }

  const token = createToken(user.id, user.username);
  return res.json({ access_token: token, token_type: "bearer", user: { id: user.id, username: user.username } });
});

export { router as authRouter };
