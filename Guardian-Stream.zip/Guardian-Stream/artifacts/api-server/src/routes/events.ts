import { Router } from "express";
import { db } from "@workspace/db";
import { eventsTable, camerasTable } from "@workspace/db";
import { eq, and, desc, sql } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  const camera_id = req.query.camera_id ? parseInt(req.query.camera_id as string) : undefined;
  const type = req.query.type as string | undefined;
  const limit = parseInt((req.query.limit as string) || "50");
  const offset = parseInt((req.query.offset as string) || "0");

  const conditions = [];
  if (camera_id) conditions.push(eq(eventsTable.camera_id, camera_id));
  if (type) conditions.push(eq(eventsTable.type, type));

  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

  const [events, [{ count }]] = await Promise.all([
    db
      .select({
        id: eventsTable.id,
        type: eventsTable.type,
        camera_id: eventsTable.camera_id,
        camera_name: camerasTable.name,
        image_path: eventsTable.image_path,
        confidence: eventsTable.confidence,
        timestamp: eventsTable.timestamp,
        metadata: eventsTable.metadata,
      })
      .from(eventsTable)
      .leftJoin(camerasTable, eq(eventsTable.camera_id, camerasTable.id))
      .where(whereClause)
      .orderBy(desc(eventsTable.timestamp))
      .limit(limit)
      .offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(eventsTable).where(whereClause),
  ]);

  return res.json({ items: events, total: Number(count), limit, offset });
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

  const [event] = await db
    .select({
      id: eventsTable.id,
      type: eventsTable.type,
      camera_id: eventsTable.camera_id,
      camera_name: camerasTable.name,
      image_path: eventsTable.image_path,
      confidence: eventsTable.confidence,
      timestamp: eventsTable.timestamp,
      metadata: eventsTable.metadata,
    })
    .from(eventsTable)
    .leftJoin(camerasTable, eq(eventsTable.camera_id, camerasTable.id))
    .where(eq(eventsTable.id, id))
    .limit(1);

  if (!event) return res.status(404).json({ error: "Event not found" });
  return res.json(event);
});

export { router as eventsRouter };
