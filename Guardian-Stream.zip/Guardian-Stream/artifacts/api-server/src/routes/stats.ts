import { Router } from "express";
import { db } from "@workspace/db";
import { eventsTable, camerasTable, recordingsTable } from "@workspace/db";
import { eq, gte, sql } from "drizzle-orm";

const router = Router();

router.get("/summary", async (req, res) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [cameras, eventsToday, recordings] = await Promise.all([
    db.select({ status: camerasTable.status }).from(camerasTable),
    db.select({ type: eventsTable.type, count: sql<number>`count(*)` })
      .from(eventsTable)
      .where(gte(eventsTable.timestamp, today))
      .groupBy(eventsTable.type),
    db.select({ count: sql<number>`count(*)`, size: sql<number>`sum(file_size_mb)` }).from(recordingsTable),
  ]);

  const online = cameras.filter(c => c.status === "online").length;
  const offline = cameras.filter(c => c.status === "offline").length;
  const eventMap = Object.fromEntries(eventsToday.map(e => [e.type, Number(e.count)]));

  return res.json({
    total_cameras: cameras.length,
    online_cameras: online,
    offline_cameras: offline,
    total_events_today: (Object.values(eventMap) as number[]).reduce((a, b) => a + b, 0),
    person_detections_today: eventMap.person || 0,
    motion_events_today: eventMap.motion || 0,
    face_detections_today: eventMap.face || 0,
    total_recordings: Number(recordings[0]?.count || 0),
    storage_used_gb: Number(recordings[0]?.size || 0) / 1024,
  });
});

router.get("/events-by-hour", async (req, res) => {
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const rows = await db
    .select({
      hour: sql<string>`to_char(date_trunc('hour', ${eventsTable.timestamp}), 'HH24:00')`,
      type: eventsTable.type,
      count: sql<number>`count(*)`,
    })
    .from(eventsTable)
    .where(gte(eventsTable.timestamp, since))
    .groupBy(sql`date_trunc('hour', ${eventsTable.timestamp})`, eventsTable.type)
    .orderBy(sql`date_trunc('hour', ${eventsTable.timestamp})`);

  return res.json(rows.map(r => ({ hour: r.hour, type: r.type, count: Number(r.count) })));
});

router.get("/events-by-camera", async (req, res) => {
  const rows = await db
    .select({
      camera_id: eventsTable.camera_id,
      camera_name: camerasTable.name,
      count: sql<number>`count(*)`,
    })
    .from(eventsTable)
    .leftJoin(camerasTable, eq(eventsTable.camera_id, camerasTable.id))
    .groupBy(eventsTable.camera_id, camerasTable.name)
    .orderBy(sql`count(*) DESC`)
    .limit(10);

  return res.json(rows.map(r => ({ camera_id: r.camera_id, camera_name: r.camera_name || "Unknown", count: Number(r.count) })));
});

export { router as statsRouter };
