import { Router } from "express";
import { db } from "@workspace/db";
import { camerasTable, insertCameraSchema } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  const cameras = await db.select().from(camerasTable).orderBy(camerasTable.id);
  return res.json(cameras);
});

router.post("/", async (req, res) => {
  const parsed = insertCameraSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.message });
  }
  const [camera] = await db.insert(camerasTable).values(parsed.data).returning();
  return res.status(201).json(camera);
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
  const [camera] = await db.select().from(camerasTable).where(eq(camerasTable.id, id)).limit(1);
  if (!camera) return res.status(404).json({ error: "Camera not found" });
  return res.json(camera);
});

router.put("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
  const [camera] = await db.update(camerasTable).set(req.body).where(eq(camerasTable.id, id)).returning();
  if (!camera) return res.status(404).json({ error: "Camera not found" });
  return res.json(camera);
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
  await db.delete(camerasTable).where(eq(camerasTable.id, id));
  return res.status(204).send();
});

export { router as camerasRouter };
