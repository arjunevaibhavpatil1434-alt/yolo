import { Router } from "express";
import { db } from "@workspace/db";
import { recordingsTable, camerasTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  const camera_id = req.query.camera_id ? parseInt(req.query.camera_id as string) : undefined;
  const limit = parseInt((req.query.limit as string) || "20");

  const query = db
    .select({
      id: recordingsTable.id,
      camera_id: recordingsTable.camera_id,
      camera_name: camerasTable.name,
      file_path: recordingsTable.file_path,
      duration_seconds: recordingsTable.duration_seconds,
      file_size_mb: recordingsTable.file_size_mb,
      timestamp: recordingsTable.timestamp,
    })
    .from(recordingsTable)
    .leftJoin(camerasTable, eq(recordingsTable.camera_id, camerasTable.id))
    .orderBy(desc(recordingsTable.timestamp))
    .limit(limit);

  if (camera_id) {
    const results = await query.where(eq(recordingsTable.camera_id, camera_id));
    return res.json(results);
  }

  const results = await query;
  return res.json(results);
});

export { router as recordingsRouter };
