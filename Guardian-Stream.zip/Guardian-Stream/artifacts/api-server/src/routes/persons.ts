/**
 * Persons router — Known person enrollment + face embedding storage.
 *
 * Face embedding extraction is performed server-side using @vladmandic/human
 * (pure JS/WASM, no Python required). In Docker production the Python AI
 * service also writes embeddings directly via the /persons/embeddings endpoint.
 *
 * POST /persons/:id/enroll  — multipart upload → detect face → extract 512-dim
 *                             ArcFace embedding → store in person_faces table.
 */
import { Router } from "express";
import { db } from "@workspace/db";
import { knownPersonsTable, personFacesTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import multer from "multer";
import path from "path";
import fs from "fs";
import crypto from "crypto";

const router = Router();

// ── File upload (multer) ──────────────────────────────────────────────────────
const FACES_DIR = process.env.FACES_DIR ?? path.join(process.cwd(), "public", "faces");
fs.mkdirSync(FACES_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: FACES_DIR,
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || ".jpg";
    cb(null, `face_${Date.now()}_${crypto.randomBytes(4).toString("hex")}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB
  fileFilter: (_req, file, cb) => {
    if (/^image\/(jpeg|png|webp)$/.test(file.mimetype)) cb(null, true);
    else cb(new Error("Only JPEG, PNG and WebP images are accepted"));
  },
});

// ── Face embedding extractor (server-side JS fallback) ───────────────────────
// Embeddings are extracted by the Python AI service (InsightFace / ArcFace).
// This function always returns null in Node.js — the AI service fills embeddings
// via POST /persons/faces/:faceId/embedding after picking up new face records.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
async function extractEmbedding(_imagePath: string): Promise<number[] | null> {
  return null;
}

// ── Helper ────────────────────────────────────────────────────────────────────
function faceUrl(imagePath: string): string {
  return `/api/faces/${path.basename(imagePath)}`;
}

async function personWithFaces(id: number) {
  const [person] = await db.select().from(knownPersonsTable).where(eq(knownPersonsTable.id, id)).limit(1);
  if (!person) return null;
  const faces = await db.select().from(personFacesTable).where(eq(personFacesTable.person_id, id));
  return {
    ...person,
    faces: faces.map(f => ({
      id: f.id,
      person_id: f.person_id,
      image_path: faceUrl(f.image_path),
      has_embedding: f.embedding !== null,
      created_at: f.created_at,
    })),
  };
}

// ── Routes ────────────────────────────────────────────────────────────────────

// GET /persons — list all
router.get("/", async (_req, res) => {
  const persons = await db.select().from(knownPersonsTable).orderBy(knownPersonsTable.name);
  const withFaces = await Promise.all(persons.map(p => personWithFaces(p.id)));
  return res.json(withFaces.filter(Boolean));
});

// POST /persons — create
router.post("/", async (req, res) => {
  const { name, notes } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: "name is required" });
  const [person] = await db.insert(knownPersonsTable).values({ name: name.trim(), notes: notes ?? "" }).returning();
  return res.status(201).json({ ...person, faces: [] });
});

// GET /persons/embeddings — internal: all embeddings for AI service cache
router.get("/embeddings", async (_req, res) => {
  const rows = await db
    .select({
      face_id: personFacesTable.id,
      person_id: personFacesTable.person_id,
      person_name: knownPersonsTable.name,
      embedding: personFacesTable.embedding,
    })
    .from(personFacesTable)
    .innerJoin(knownPersonsTable, eq(personFacesTable.person_id, knownPersonsTable.id));
  return res.json(rows);
});

// GET /persons/:id
router.get("/:id", async (req, res) => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
  const p = await personWithFaces(id);
  if (!p) return res.status(404).json({ error: "Person not found" });
  return res.json(p);
});

// PUT /persons/:id
router.put("/:id", async (req, res) => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
  const { name, notes } = req.body;
  const updates: Record<string, unknown> = { updated_at: new Date() };
  if (name !== undefined) updates.name = name.trim();
  if (notes !== undefined) updates.notes = notes;
  const [person] = await db.update(knownPersonsTable).set(updates).where(eq(knownPersonsTable.id, id)).returning();
  if (!person) return res.status(404).json({ error: "Person not found" });
  return res.json(await personWithFaces(id));
});

// DELETE /persons/:id
router.delete("/:id", async (req, res) => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
  // Delete face image files
  const faces = await db.select().from(personFacesTable).where(eq(personFacesTable.person_id, id));
  for (const f of faces) {
    try { fs.unlinkSync(f.image_path); } catch { /* ignore */ }
  }
  await db.delete(personFacesTable).where(eq(personFacesTable.person_id, id));
  await db.delete(knownPersonsTable).where(eq(knownPersonsTable.id, id));
  return res.status(204).send();
});

// POST /persons/:id/enroll — upload face photo
router.post("/:id/enroll", upload.single("file"), async (req, res) => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
  if (!req.file) return res.status(400).json({ error: "No file uploaded" });

  const [person] = await db.select().from(knownPersonsTable).where(eq(knownPersonsTable.id, id)).limit(1);
  if (!person) return res.status(404).json({ error: "Person not found" });

  const imagePath = req.file.path;

  // Try server-side embedding extraction (optional JS/WASM approach)
  const embedding = await extractEmbedding(imagePath);

  const [face] = await db.insert(personFacesTable).values({
    person_id: id,
    image_path: imagePath,
    embedding: embedding as any,
  }).returning();

  // Update face_count and thumbnail
  await db.update(knownPersonsTable)
    .set({
      face_count: sql`${knownPersonsTable.face_count} + 1`,
      thumbnail_path: faceUrl(imagePath),
      updated_at: new Date(),
    })
    .where(eq(knownPersonsTable.id, id));

  return res.status(201).json({
    id: face.id,
    person_id: face.person_id,
    image_path: faceUrl(imagePath),
    has_embedding: embedding !== null,
    created_at: face.created_at,
  });
});

// DELETE /persons/:id/faces/:faceId
router.delete("/:id/faces/:faceId", async (req, res) => {
  const personId = parseInt(req.params.id);
  const faceId = parseInt(req.params.faceId);
  if (isNaN(personId) || isNaN(faceId)) return res.status(400).json({ error: "Invalid ID" });

  const [face] = await db.select().from(personFacesTable)
    .where(eq(personFacesTable.id, faceId))
    .limit(1);
  if (!face || face.person_id !== personId) return res.status(404).json({ error: "Face not found" });

  try { fs.unlinkSync(face.image_path); } catch { /* ignore */ }
  await db.delete(personFacesTable).where(eq(personFacesTable.id, faceId));
  await db.update(knownPersonsTable)
    .set({ face_count: sql`GREATEST(${knownPersonsTable.face_count} - 1, 0)`, updated_at: new Date() })
    .where(eq(knownPersonsTable.id, personId));

  return res.status(204).send();
});

// POST /persons/faces/:faceId/embedding — AI service writes embedding back
router.post("/faces/:faceId/embedding", async (req, res) => {
  const faceId = parseInt(req.params.faceId);
  if (isNaN(faceId)) return res.status(400).json({ error: "Invalid ID" });
  const { embedding } = req.body;
  if (!Array.isArray(embedding)) return res.status(400).json({ error: "embedding must be an array" });
  await db.update(personFacesTable).set({ embedding: embedding as any }).where(eq(personFacesTable.id, faceId));
  return res.json({ ok: true });
});

export { router as personsRouter };
