import { Router, type IRouter } from "express";
import path from "path";
import express from "express";
import healthRouter from "./health";
import { authRouter } from "./auth";
import { camerasRouter } from "./cameras";
import { eventsRouter } from "./events";
import { recordingsRouter } from "./recordings";
import { statsRouter } from "./stats";
import { personsRouter } from "./persons";

const router: IRouter = Router();

// Serve uploaded face images as static files
const FACES_DIR = process.env.FACES_DIR ?? path.join(process.cwd(), "public", "faces");
router.use("/faces", express.static(FACES_DIR));

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/cameras", camerasRouter);
router.use("/events", eventsRouter);
router.use("/recordings", recordingsRouter);
router.use("/stats", statsRouter);
router.use("/persons", personsRouter);

export default router;
