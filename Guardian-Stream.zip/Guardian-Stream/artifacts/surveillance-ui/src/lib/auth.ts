import { useEffect } from "react";
import { useLocation } from "wouter";
import { setAuthTokenGetter } from "@workspace/api-client-react";

const TOKEN_KEY = "sentinel_token";

// Wire JWT token into every API request automatically
setAuthTokenGetter(() => localStorage.getItem(TOKEN_KEY));

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

export function useAuthGuard() {
  const [location, setLocation] = useLocation();

  useEffect(() => {
    const token = getToken();
    if (!token && location !== "/login") {
      setLocation("/login");
    } else if (token && location === "/login") {
      setLocation("/");
    }
  }, [location, setLocation]);

  return { isAuthenticated: !!getToken() };
}
