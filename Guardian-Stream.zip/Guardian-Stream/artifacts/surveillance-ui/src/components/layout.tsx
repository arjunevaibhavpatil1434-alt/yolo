import { Link, useLocation } from "wouter";
import { clearToken } from "@/lib/auth";
import {
  LayoutDashboard,
  Camera,
  AlertTriangle,
  Video,
  LogOut,
  Shield,
  Activity,
  UserCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/cameras", icon: Camera, label: "Cameras" },
  { href: "/events", icon: AlertTriangle, label: "Events" },
  { href: "/recordings", icon: Video, label: "Recordings" },
  { href: "/persons", icon: UserCheck, label: "Known Persons" },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();

  function handleLogout() {
    clearToken();
    setLocation("/login");
  }

  return (
    <div className="flex min-h-screen bg-background text-foreground">
      {/* Sidebar */}
      <aside className="w-60 flex-shrink-0 flex flex-col bg-sidebar border-r border-sidebar-border">
        {/* Logo */}
        <div className="h-16 flex items-center gap-3 px-5 border-b border-sidebar-border">
          <div className="w-8 h-8 rounded bg-primary/10 border border-primary/30 flex items-center justify-center">
            <Shield className="w-4 h-4 text-primary" />
          </div>
          <div>
            <div className="font-mono font-bold text-sm text-foreground tracking-wide">SENTINEL</div>
            <div className="font-mono text-[10px] text-muted-foreground tracking-widest">VIEW</div>
          </div>
          <div className="ml-auto flex items-center gap-1">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
          </div>
        </div>

        {/* System status */}
        <div className="px-4 py-3 border-b border-sidebar-border">
          <div className="flex items-center gap-2 text-[10px] font-mono text-muted-foreground">
            <Activity className="w-3 h-3 text-primary" />
            <span className="text-primary">SYSTEM ACTIVE</span>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map(({ href, icon: Icon, label }) => {
            const active = location === href;
            return (
              <Link key={href} href={href}>
                <div
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-mono cursor-pointer transition-all duration-150",
                    active
                      ? "bg-primary/10 text-primary border border-primary/20"
                      : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-foreground border border-transparent"
                  )}
                >
                  <Icon className={cn("w-4 h-4 flex-shrink-0", active ? "text-primary" : "opacity-60")} />
                  {label}
                  {active && <div className="ml-auto w-1 h-4 rounded-full bg-primary" />}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-3 border-t border-sidebar-border">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-mono text-muted-foreground hover:bg-destructive/10 hover:text-destructive border border-transparent hover:border-destructive/20 transition-all duration-150 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col min-h-screen overflow-auto">
        {children}
      </main>
    </div>
  );
}

export function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="h-16 flex items-center gap-4 px-6 border-b border-border bg-background/50 backdrop-blur-sm flex-shrink-0">
      <div>
        <h1 className="font-mono font-bold text-sm text-foreground tracking-wide uppercase">{title}</h1>
        {subtitle && <p className="font-mono text-[11px] text-muted-foreground">{subtitle}</p>}
      </div>
      <div className="ml-auto font-mono text-[11px] text-muted-foreground tabular-nums">
        {new Date().toLocaleTimeString([], { hour12: false })}
      </div>
    </div>
  );
}
