import { useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import { Camera } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";

interface VideoPlayerProps {
  camera: Camera;
  className?: string;
}

export function VideoPlayer({ camera, className = "" }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let hls: Hls | null = null;

    if (camera.stream_url && camera.status !== "offline") {
      if (Hls.isSupported()) {
        hls = new Hls({
          enableWorker: true,
          lowLatencyMode: true,
        });
        hls.loadSource(camera.stream_url);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          video.play().catch((e) => console.error("Video play failed:", e));
        });
        hls.on(Hls.Events.ERROR, (event, data) => {
          if (data.fatal) {
            setError("Stream error");
          }
        });
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = camera.stream_url;
        video.addEventListener("loadedmetadata", () => {
          video.play().catch((e) => console.error("Video play failed:", e));
        });
      }
    }

    return () => {
      if (hls) {
        hls.destroy();
      }
    };
  }, [camera.stream_url, camera.status]);

  const getStatusBadge = () => {
    switch (camera.status) {
      case "online":
        return <Badge className="bg-green-500/20 text-green-500 border-green-500/30 font-mono text-xs">ONLINE</Badge>;
      case "recording":
        return (
          <Badge className="bg-red-500/20 text-red-500 border-red-500/30 animate-pulse font-mono text-xs">
            REC
          </Badge>
        );
      case "offline":
        return <Badge className="bg-muted text-muted-foreground border-border font-mono text-xs">OFFLINE</Badge>;
    }
  };

  const isStreamAvailable = camera.stream_url && camera.status !== "offline" && !error;

  return (
    <div className={`relative overflow-hidden bg-card border border-border rounded-lg group ${className}`}>
      {isStreamAvailable ? (
        <video
          ref={videoRef}
          className="w-full h-full object-cover"
          muted
          autoPlay
          playsInline
        />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center bg-black/40 text-muted-foreground">
          <div className="text-4xl mb-2 opacity-50 font-mono">NO SIGNAL</div>
          <div className="text-sm font-mono opacity-50">{error || "Stream unavailable"}</div>
        </div>
      )}
      
      {/* Overlay */}
      <div className="absolute top-0 left-0 right-0 p-3 bg-gradient-to-b from-black/80 to-transparent flex justify-between items-start pointer-events-none">
        <div className="flex flex-col gap-1">
          <div className="font-mono text-sm font-semibold text-white drop-shadow-md">
            {camera.name}
          </div>
          <div className="font-mono text-[10px] text-white/70 drop-shadow-md">
            {camera.location}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {camera.status === "online" && (
            <div className="flex items-center gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              <span className="font-mono text-[10px] font-bold text-primary tracking-widest drop-shadow-md">LIVE</span>
            </div>
          )}
          {getStatusBadge()}
        </div>
      </div>
    </div>
  );
}
