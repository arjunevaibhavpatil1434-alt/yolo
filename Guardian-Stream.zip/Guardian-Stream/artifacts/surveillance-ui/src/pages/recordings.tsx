import { Layout, PageHeader } from "@/components/layout";
import {
  useListRecordings,
  useListCameras,
  getListRecordingsQueryKey,
  getListCamerasQueryKey,
} from "@workspace/api-client-react";
import type { ListRecordingsParams } from "@workspace/api-client-react";
import { useState } from "react";
import { Video, HardDrive, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

function formatDuration(seconds: number) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

export function RecordingsPage() {
  const [cameraFilter, setCameraFilter] = useState<number | undefined>();
  const { data: cameras = [] } = useListCameras({ query: { queryKey: getListCamerasQueryKey() } });

  const params: ListRecordingsParams = {
    limit: 50,
    ...(cameraFilter ? { camera_id: cameraFilter } : {}),
  };

  const { data: recordings = [], isLoading } = useListRecordings(params, { query: { queryKey: getListRecordingsQueryKey(params), refetchInterval: 30000 } });

  const totalSize = recordings.reduce((acc, r) => acc + r.file_size_mb, 0);
  const totalDuration = recordings.reduce((acc, r) => acc + r.duration_seconds, 0);

  return (
    <Layout>
      <PageHeader title="Recordings" subtitle={`${recordings.length} segments stored`} />
      <div className="flex-1 p-6 space-y-4">

        {/* Summary cards */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <Video className="w-4 h-4 text-primary" />
            <div>
              <div className="font-mono text-lg font-bold text-foreground">{recordings.length}</div>
              <div className="font-mono text-[10px] text-muted-foreground uppercase">Segments</div>
            </div>
          </div>
          <div className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <HardDrive className="w-4 h-4 text-amber-400" />
            <div>
              <div className="font-mono text-lg font-bold text-foreground">{totalSize.toFixed(1)} MB</div>
              <div className="font-mono text-[10px] text-muted-foreground uppercase">Storage</div>
            </div>
          </div>
          <div className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <Clock className="w-4 h-4 text-green-400" />
            <div>
              <div className="font-mono text-lg font-bold text-foreground">{formatDuration(totalDuration)}</div>
              <div className="font-mono text-[10px] text-muted-foreground uppercase">Total Duration</div>
            </div>
          </div>
        </div>

        {/* Camera filter */}
        {cameras.length > 0 && (
          <div className="flex items-center gap-3">
            <select
              value={cameraFilter ?? ""}
              onChange={e => setCameraFilter(e.target.value ? Number(e.target.value) : undefined)}
              className="bg-card border border-border rounded-md px-3 py-1.5 text-xs font-mono text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            >
              <option value="">All Cameras</option>
              {cameras.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
        )}

        {/* Recordings table */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="grid grid-cols-[auto_1fr_1fr_auto_auto_auto] text-[10px] font-mono text-muted-foreground uppercase tracking-wider px-4 py-2.5 border-b border-border bg-muted/20">
            <span className="pr-4">#</span>
            <span>Camera</span>
            <span>File</span>
            <span>Duration</span>
            <span>Size</span>
            <span>Recorded</span>
          </div>

          {isLoading ? (
            <div className="space-y-px">
              {[...Array(5)].map((_, i) => <div key={i} className="h-14 animate-pulse border-b border-border/30 bg-background/30" />)}
            </div>
          ) : recordings.length === 0 ? (
            <div className="py-16 text-center">
              <Video className="w-8 h-8 text-muted-foreground mx-auto mb-3 opacity-30" />
              <p className="font-mono text-sm text-muted-foreground">No recordings found</p>
              <p className="font-mono text-xs text-muted-foreground mt-1">Recordings are created automatically during live streaming</p>
            </div>
          ) : (
            recordings.map((rec, i) => (
              <div
                key={rec.id}
                className={cn(
                  "grid grid-cols-[auto_1fr_1fr_auto_auto_auto] items-center px-4 py-3 border-b border-border/40 hover:bg-accent/30 transition-colors gap-4",
                  i % 2 === 0 ? "" : "bg-background/20"
                )}
              >
                <span className="font-mono text-[10px] text-muted-foreground/60 pr-4">#{rec.id}</span>
                <span className="font-mono text-xs text-foreground">{rec.camera_name}</span>
                <span className="font-mono text-[10px] text-muted-foreground truncate">{rec.file_path.split("/").pop()}</span>
                <span className="font-mono text-xs text-foreground tabular-nums">{formatDuration(rec.duration_seconds)}</span>
                <span className="font-mono text-xs text-amber-400 tabular-nums">{rec.file_size_mb.toFixed(1)} MB</span>
                <span className="font-mono text-[10px] text-muted-foreground tabular-nums">
                  {new Date(rec.timestamp).toLocaleString([], { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false })}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </Layout>
  );
}
