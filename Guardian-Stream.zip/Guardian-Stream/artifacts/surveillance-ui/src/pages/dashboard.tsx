import { Layout, PageHeader } from "@/components/layout";
import { VideoPlayer } from "@/components/video-player";
import {
  useListCameras,
  useGetDashboardStats,
  useGetEventsByHour,
  useGetEventsByCamera,
  useListEvents,
  getListCamerasQueryKey,
  getGetDashboardStatsQueryKey,
  getGetEventsByHourQueryKey,
  getGetEventsByCameraQueryKey,
  getListEventsQueryKey,
} from "@workspace/api-client-react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import { Camera, AlertTriangle, Activity, HardDrive, Users, Eye, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

function StatCard({ label, value, icon: Icon, accent }: {
  label: string;
  value: string | number;
  icon: React.ElementType;
  accent?: string;
}) {
  return (
    <div className="bg-card border border-border rounded-lg p-4 flex items-center gap-4">
      <div className={cn("w-10 h-10 rounded-md flex items-center justify-center flex-shrink-0", accent || "bg-primary/10")}>
        <Icon className={cn("w-5 h-5", accent ? "text-white" : "text-primary")} />
      </div>
      <div>
        <div className="font-mono text-2xl font-bold text-foreground tabular-nums">{value}</div>
        <div className="font-mono text-[10px] text-muted-foreground uppercase tracking-wider">{label}</div>
      </div>
    </div>
  );
}

const EVENT_COLORS = { motion: "#f59e0b", person: "#3b82f6", face: "#22c55e" };

export function DashboardPage() {
  const { data: cameras = [] } = useListCameras({ query: { queryKey: getListCamerasQueryKey(), refetchInterval: 10000 } });
  const { data: stats } = useGetDashboardStats({ query: { queryKey: getGetDashboardStatsQueryKey(), refetchInterval: 15000 } });
  const { data: byHour = [] } = useGetEventsByHour({ query: { queryKey: getGetEventsByHourQueryKey(), refetchInterval: 30000 } });
  const { data: byCamera = [] } = useGetEventsByCamera({ query: { queryKey: getGetEventsByCameraQueryKey(), refetchInterval: 30000 } });
  const { data: recentEvents } = useListEvents({ limit: 8 }, { query: { queryKey: getListEventsQueryKey({ limit: 8 }), refetchInterval: 10000 } });

  // Aggregate hourly data for chart
  const hourlyData = (() => {
    const map: Record<string, Record<string, number>> = {};
    byHour.forEach(({ hour, type, count }) => {
      if (!map[hour]) map[hour] = {};
      map[hour][type] = count;
    });
    return Object.entries(map).map(([hour, types]) => ({ hour, ...types }));
  })();

  return (
    <Layout>
      <PageHeader title="Dashboard" subtitle="Live surveillance overview" />
      <div className="flex-1 p-6 space-y-6 overflow-auto">

        {/* Stats row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatCard label="Cameras Online" value={`${stats?.online_cameras ?? 0}/${stats?.total_cameras ?? 0}`} icon={Camera} />
          <StatCard label="Events Today" value={stats?.total_events_today ?? 0} icon={AlertTriangle} />
          <StatCard label="Person Detections" value={stats?.person_detections_today ?? 0} icon={Users} />
          <StatCard label="Storage Used" value={`${(stats?.storage_used_gb ?? 0).toFixed(1)} GB`} icon={HardDrive} />
        </div>

        {/* Secondary stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <Zap className="w-4 h-4 text-amber-400" />
            <div>
              <div className="font-mono text-sm font-bold text-amber-400">{stats?.motion_events_today ?? 0}</div>
              <div className="font-mono text-[10px] text-muted-foreground uppercase">Motion</div>
            </div>
          </div>
          <div className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <Users className="w-4 h-4 text-blue-400" />
            <div>
              <div className="font-mono text-sm font-bold text-blue-400">{stats?.person_detections_today ?? 0}</div>
              <div className="font-mono text-[10px] text-muted-foreground uppercase">Person</div>
            </div>
          </div>
          <div className="bg-card border border-border rounded-lg p-3 flex items-center gap-3">
            <Eye className="w-4 h-4 text-green-400" />
            <div>
              <div className="font-mono text-sm font-bold text-green-400">{stats?.face_detections_today ?? 0}</div>
              <div className="font-mono text-[10px] text-muted-foreground uppercase">Face</div>
            </div>
          </div>
        </div>

        {/* Camera grid */}
        <div>
          <h2 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-3">Live Feeds</h2>
          {cameras.length === 0 ? (
            <div className="bg-card border border-border rounded-lg p-12 text-center">
              <Camera className="w-8 h-8 text-muted-foreground mx-auto mb-3 opacity-40" />
              <p className="font-mono text-sm text-muted-foreground">No cameras configured</p>
              <p className="font-mono text-xs text-muted-foreground mt-1">Add cameras in the Cameras tab</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {cameras.slice(0, 6).map(camera => (
                <VideoPlayer key={camera.id} camera={camera} className="aspect-video camera-scanline" />
              ))}
            </div>
          )}
        </div>

        {/* Charts + Recent events */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Hourly chart */}
          <div className="lg:col-span-2 bg-card border border-border rounded-lg p-4">
            <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4">Events — Last 24 Hours</h3>
            {hourlyData.length === 0 ? (
              <div className="h-40 flex items-center justify-center">
                <p className="font-mono text-xs text-muted-foreground">No event data yet</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={160}>
                <AreaChart data={hourlyData}>
                  <defs>
                    <linearGradient id="motionGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="personGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 16%)" />
                  <XAxis dataKey="hour" tick={{ fill: "hsl(210 12% 55%)", fontSize: 10, fontFamily: "monospace" }} />
                  <YAxis tick={{ fill: "hsl(210 12% 55%)", fontSize: 10, fontFamily: "monospace" }} />
                  <Tooltip
                    contentStyle={{ background: "hsl(220 18% 9%)", border: "1px solid hsl(220 15% 18%)", borderRadius: "6px", fontFamily: "monospace", fontSize: "11px" }}
                    labelStyle={{ color: "hsl(210 20% 88%)" }}
                  />
                  <Area type="monotone" dataKey="motion" stroke="#f59e0b" fill="url(#motionGrad)" strokeWidth={1.5} />
                  <Area type="monotone" dataKey="person" stroke="#3b82f6" fill="url(#personGrad)" strokeWidth={1.5} />
                  <Area type="monotone" dataKey="face" stroke="#22c55e" fill="transparent" strokeWidth={1.5} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* Recent events */}
          <div className="bg-card border border-border rounded-lg p-4">
            <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-3">Recent Alerts</h3>
            <div className="space-y-2">
              {(recentEvents?.items ?? []).length === 0 ? (
                <p className="font-mono text-xs text-muted-foreground py-4 text-center">No events detected</p>
              ) : (
                (recentEvents?.items ?? []).map(event => (
                  <div key={event.id} className="flex items-center gap-2.5 p-2 rounded-md bg-background/50 border border-border/50">
                    <div className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", {
                      "bg-amber-400": event.type === "motion",
                      "bg-blue-400": event.type === "person",
                      "bg-green-400": event.type === "face",
                    })} />
                    <div className="flex-1 min-w-0">
                      <div className="font-mono text-xs font-semibold text-foreground uppercase">{event.type}</div>
                      <div className="font-mono text-[10px] text-muted-foreground truncate">{event.camera_name}</div>
                    </div>
                    <div className="font-mono text-[10px] text-muted-foreground tabular-nums flex-shrink-0">
                      {new Date(event.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Per-camera bar chart */}
        {byCamera.length > 0 && (
          <div className="bg-card border border-border rounded-lg p-4">
            <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-4">Events by Camera</h3>
            <ResponsiveContainer width="100%" height={120}>
              <BarChart data={byCamera}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 16%)" />
                <XAxis dataKey="camera_name" tick={{ fill: "hsl(210 12% 55%)", fontSize: 10, fontFamily: "monospace" }} />
                <YAxis tick={{ fill: "hsl(210 12% 55%)", fontSize: 10, fontFamily: "monospace" }} />
                <Tooltip
                  contentStyle={{ background: "hsl(220 18% 9%)", border: "1px solid hsl(220 15% 18%)", borderRadius: "6px", fontFamily: "monospace", fontSize: "11px" }}
                />
                <Bar dataKey="count" fill="hsl(210 100% 56%)" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </Layout>
  );
}
