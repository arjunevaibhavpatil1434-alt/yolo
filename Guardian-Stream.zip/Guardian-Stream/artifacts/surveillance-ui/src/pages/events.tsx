import { useState } from "react";
import { Layout, PageHeader } from "@/components/layout";
import {
  useListEvents,
  useListCameras,
  getListEventsQueryKey,
  getListCamerasQueryKey,
} from "@workspace/api-client-react";
import type { ListEventsParams } from "@workspace/api-client-react";
import { ChevronLeft, ChevronRight, Filter } from "lucide-react";
import { cn } from "@/lib/utils";

const EVENT_TYPES = ["motion", "person", "face"] as const;

function EventBadge({ type }: { type: string }) {
  return (
    <span className={cn("font-mono text-[10px] font-bold uppercase px-2 py-0.5 rounded border", {
      "text-amber-400 bg-amber-400/10 border-amber-400/20": type === "motion",
      "text-blue-400 bg-blue-400/10 border-blue-400/20": type === "person",
      "text-green-400 bg-green-400/10 border-green-400/20": type === "face",
    })}>
      {type}
    </span>
  );
}

function ConfidenceBar({ value }: { value: number }) {
  const pct = Math.round(value * 100);
  return (
    <div className="flex items-center gap-2">
      <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
        <div
          className={cn("h-full rounded-full", pct > 80 ? "bg-green-400" : pct > 50 ? "bg-amber-400" : "bg-red-400")}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="font-mono text-[10px] text-muted-foreground tabular-nums">{pct}%</span>
    </div>
  );
}

const PAGE_SIZE = 20;

export function EventsPage() {
  const [page, setPage] = useState(0);
  const [typeFilter, setTypeFilter] = useState<string>("");
  const [cameraFilter, setCameraFilter] = useState<number | undefined>();

  const params: ListEventsParams = {
    limit: PAGE_SIZE,
    offset: page * PAGE_SIZE,
    ...(typeFilter ? { type: typeFilter as any } : {}),
    ...(cameraFilter ? { camera_id: cameraFilter } : {}),
  };

  const { data, isLoading } = useListEvents(params, { query: { queryKey: getListEventsQueryKey(params), refetchInterval: 15000 } });
  const { data: cameras = [] } = useListCameras({ query: { queryKey: getListCamerasQueryKey() } });

  const events = data?.items ?? [];
  const total = data?.total ?? 0;
  const totalPages = Math.ceil(total / PAGE_SIZE);

  function resetPage() { setPage(0); }

  return (
    <Layout>
      <PageHeader title="Events" subtitle={`${total} total detection events`} />
      <div className="flex-1 p-6 space-y-4">

        {/* Filters */}
        <div className="flex items-center gap-3 flex-wrap">
          <Filter className="w-3.5 h-3.5 text-muted-foreground" />
          <div className="flex gap-2">
            <button
              onClick={() => { setTypeFilter(""); resetPage(); }}
              className={cn("font-mono text-xs px-3 py-1.5 rounded border transition-colors", !typeFilter ? "bg-primary/10 text-primary border-primary/30" : "text-muted-foreground border-border hover:border-primary/30 hover:text-primary")}
            >All Types</button>
            {EVENT_TYPES.map(t => (
              <button
                key={t}
                onClick={() => { setTypeFilter(t); resetPage(); }}
                className={cn("font-mono text-xs px-3 py-1.5 rounded border transition-colors uppercase", typeFilter === t
                  ? t === "motion" ? "bg-amber-400/10 text-amber-400 border-amber-400/30"
                    : t === "person" ? "bg-blue-400/10 text-blue-400 border-blue-400/30"
                    : "bg-green-400/10 text-green-400 border-green-400/30"
                  : "text-muted-foreground border-border hover:border-primary/30 hover:text-primary"
                )}
              >{t}</button>
            ))}
          </div>
          {cameras.length > 0 && (
            <select
              value={cameraFilter ?? ""}
              onChange={e => { setCameraFilter(e.target.value ? Number(e.target.value) : undefined); resetPage(); }}
              className="bg-card border border-border rounded-md px-3 py-1.5 text-xs font-mono text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            >
              <option value="">All Cameras</option>
              {cameras.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          )}
        </div>

        {/* Table */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="grid grid-cols-[1fr_1fr_1fr_auto_auto] text-[10px] font-mono text-muted-foreground uppercase tracking-wider px-4 py-2.5 border-b border-border bg-muted/20">
            <span>Type</span>
            <span>Camera</span>
            <span>Timestamp</span>
            <span>Confidence</span>
            <span>ID</span>
          </div>

          {isLoading ? (
            <div className="space-y-px">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-12 bg-background/30 animate-pulse border-b border-border/30" />
              ))}
            </div>
          ) : events.length === 0 ? (
            <div className="py-16 text-center">
              <p className="font-mono text-sm text-muted-foreground">No events found</p>
              {(typeFilter || cameraFilter) && (
                <p className="font-mono text-xs text-muted-foreground mt-1">Try clearing filters</p>
              )}
            </div>
          ) : (
            <div>
              {events.map((event, i) => (
                <div
                  key={event.id}
                  className={cn(
                    "grid grid-cols-[1fr_1fr_1fr_auto_auto] items-center px-4 py-3 border-b border-border/40 hover:bg-accent/30 transition-colors",
                    i % 2 === 0 ? "" : "bg-background/20"
                  )}
                >
                  <EventBadge type={event.type} />
                  <span className="font-mono text-xs text-foreground">{event.camera_name}</span>
                  <span className="font-mono text-xs text-muted-foreground tabular-nums">
                    {new Date(event.timestamp).toLocaleString([], { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false })}
                  </span>
                  <ConfidenceBar value={event.confidence} />
                  <span className="font-mono text-[10px] text-muted-foreground/60 pl-4">#{event.id}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs text-muted-foreground">
              Page {page + 1} of {totalPages} &mdash; {total} events
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage(p => Math.max(0, p - 1))}
                disabled={page === 0}
                className="p-1.5 rounded border border-border text-muted-foreground hover:text-foreground hover:bg-accent disabled:opacity-40 transition-colors"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                disabled={page >= totalPages - 1}
                className="p-1.5 rounded border border-border text-muted-foreground hover:text-foreground hover:bg-accent disabled:opacity-40 transition-colors"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
