import { useState } from "react";
import { Layout, PageHeader } from "@/components/layout";
import {
  useListCameras,
  useCreateCamera,
  useUpdateCamera,
  useDeleteCamera,
  getListCamerasQueryKey,
} from "@workspace/api-client-react";
import type { Camera, CreateCameraBody, UpdateCameraBody } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Wifi, WifiOff, Radio, X, Check } from "lucide-react";
import { cn } from "@/lib/utils";

function StatusBadge({ status }: { status: string }) {
  if (status === "online")
    return <span className="inline-flex items-center gap-1.5 font-mono text-[10px] text-green-400 bg-green-400/10 border border-green-400/20 px-2 py-0.5 rounded-full"><Wifi className="w-2.5 h-2.5" />ONLINE</span>;
  if (status === "recording")
    return <span className="inline-flex items-center gap-1.5 font-mono text-[10px] text-red-400 bg-red-400/10 border border-red-400/20 px-2 py-0.5 rounded-full rec-blink"><Radio className="w-2.5 h-2.5" />REC</span>;
  return <span className="inline-flex items-center gap-1.5 font-mono text-[10px] text-muted-foreground bg-muted/30 border border-border px-2 py-0.5 rounded-full"><WifiOff className="w-2.5 h-2.5" />OFFLINE</span>;
}

type FormData = { name: string; rtsp_url: string; location: string };
const EMPTY: FormData = { name: "", rtsp_url: "", location: "" };

function CameraForm({
  initial,
  onSave,
  onCancel,
  isPending,
}: {
  initial?: FormData;
  onSave: (data: FormData) => void;
  onCancel: () => void;
  isPending: boolean;
}) {
  const [form, setForm] = useState<FormData>(initial || EMPTY);
  const set = (k: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement>) => setForm(f => ({ ...f, [k]: e.target.value }));

  return (
    <div className="bg-background/60 border border-primary/20 rounded-lg p-4 space-y-3">
      {[
        { key: "name" as const, label: "Camera Name", placeholder: "Entrance Camera" },
        { key: "rtsp_url" as const, label: "RTSP URL", placeholder: "rtsp://192.168.1.100:554/stream" },
        { key: "location" as const, label: "Location", placeholder: "Main Entrance" },
      ].map(({ key, label, placeholder }) => (
        <div key={key}>
          <label className="block font-mono text-[10px] text-muted-foreground uppercase tracking-wider mb-1">{label}</label>
          <input
            value={form[key]}
            onChange={set(key)}
            placeholder={placeholder}
            className="w-full bg-card border border-input rounded-md px-3 py-2 text-sm font-mono text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-colors"
          />
        </div>
      ))}
      <div className="flex gap-2 pt-1">
        <button
          onClick={() => onSave(form)}
          disabled={isPending || !form.name || !form.rtsp_url}
          className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground font-mono text-xs rounded-md hover:bg-primary/90 disabled:opacity-50 transition-colors"
        >
          <Check className="w-3.5 h-3.5" />
          {isPending ? "Saving..." : "Save"}
        </button>
        <button onClick={onCancel} className="flex items-center gap-1.5 px-4 py-2 bg-muted text-muted-foreground font-mono text-xs rounded-md hover:bg-muted/80 transition-colors">
          <X className="w-3.5 h-3.5" />Cancel
        </button>
      </div>
    </div>
  );
}

export function CamerasPage() {
  const qc = useQueryClient();
  const { data: cameras = [], isLoading } = useListCameras({ query: { queryKey: getListCamerasQueryKey() } });
  const [showAdd, setShowAdd] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);

  const invalidate = () => qc.invalidateQueries({ queryKey: getListCamerasQueryKey() });

  const createMutation = useCreateCamera({ mutation: { onSuccess: () => { invalidate(); setShowAdd(false); } } });
  const updateMutation = useUpdateCamera({ mutation: { onSuccess: () => { invalidate(); setEditId(null); } } });
  const deleteMutation = useDeleteCamera({ mutation: { onSuccess: () => invalidate() } });

  return (
    <Layout>
      <PageHeader title="Cameras" subtitle={`${cameras.length} camera${cameras.length !== 1 ? "s" : ""} configured`} />
      <div className="flex-1 p-6 space-y-4">

        {/* Add button */}
        <div className="flex justify-end">
          <button
            onClick={() => { setShowAdd(v => !v); setEditId(null); }}
            className="flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary border border-primary/30 font-mono text-xs rounded-md hover:bg-primary/20 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Camera
          </button>
        </div>

        {showAdd && (
          <CameraForm
            onSave={(data) => createMutation.mutate({ data: data as CreateCameraBody })}
            onCancel={() => setShowAdd(false)}
            isPending={createMutation.isPending}
          />
        )}

        {/* Camera list */}
        {isLoading ? (
          <div className="space-y-2">
            {[1, 2, 3].map(i => <div key={i} className="h-20 bg-card border border-border rounded-lg animate-pulse" />)}
          </div>
        ) : cameras.length === 0 ? (
          <div className="bg-card border border-border rounded-lg p-16 text-center">
            <p className="font-mono text-sm text-muted-foreground">No cameras configured</p>
            <p className="font-mono text-xs text-muted-foreground mt-1">Click "Add Camera" to get started</p>
          </div>
        ) : (
          <div className="space-y-2">
            {cameras.map(camera => (
              <div key={camera.id} className="bg-card border border-border rounded-lg overflow-hidden">
                <div className="flex items-center gap-4 p-4">
                  <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center flex-shrink-0 font-mono text-xs text-muted-foreground">
                    {String(camera.id).padStart(2, "0")}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-semibold text-sm text-foreground">{camera.name}</span>
                      <StatusBadge status={camera.status} />
                    </div>
                    <div className="font-mono text-xs text-muted-foreground mt-0.5 truncate">{camera.rtsp_url}</div>
                    <div className="font-mono text-[10px] text-muted-foreground/70 mt-0.5">{camera.location}</div>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <button
                      onClick={() => { setEditId(camera.id === editId ? null : camera.id); setShowAdd(false); }}
                      className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteMutation.mutate({ id: camera.id })}
                      className="p-2 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                {editId === camera.id && (
                  <div className="border-t border-border p-4">
                    <CameraForm
                      initial={{ name: camera.name, rtsp_url: camera.rtsp_url, location: camera.location }}
                      onSave={(data) => updateMutation.mutate({ id: camera.id, data: data as UpdateCameraBody })}
                      onCancel={() => setEditId(null)}
                      isPending={updateMutation.isPending}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
