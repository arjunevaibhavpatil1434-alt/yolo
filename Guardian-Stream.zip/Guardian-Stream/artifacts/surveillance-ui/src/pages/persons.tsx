import { useState, useRef } from "react";
import { Layout } from "@/components/layout";
import {
  useListPersons,
  useCreatePerson,
  useDeletePerson,
  useEnrollFace,
  useDeletePersonFace,
  getListPersonsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { UserCheck, UserPlus, Trash2, Upload, Camera, Shield, X, AlertCircle, Image } from "lucide-react";

export function PersonsPage() {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: getListPersonsQueryKey() });

  const { data: persons = [], isLoading } = useListPersons({
    query: { queryKey: getListPersonsQueryKey(), refetchInterval: 30000 },
  });

  const createMutation = useCreatePerson({ mutation: { onSuccess: invalidate } });
  const deleteMutation = useDeletePerson({ mutation: { onSuccess: invalidate } });

  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState("");
  const [newNotes, setNewNotes] = useState("");
  const [selectedPersonId, setSelectedPersonId] = useState<number | null>(null);
  const [enrollError, setEnrollError] = useState("");

  function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!newName.trim()) return;
    createMutation.mutate(
      { data: { name: newName.trim(), notes: newNotes.trim() } },
      { onSuccess: () => { setShowAdd(false); setNewName(""); setNewNotes(""); } },
    );
  }

  const selectedPerson = persons.find(p => p.id === selectedPersonId) ?? null;

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-mono font-bold text-xl text-foreground flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-primary" />
              KNOWN PERSONS
            </h1>
            <p className="text-xs text-muted-foreground font-mono mt-0.5">
              Face enrollment database — {persons.length} person{persons.length !== 1 ? "s" : ""} registered
            </p>
          </div>
          <button
            onClick={() => setShowAdd(true)}
            className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2 rounded-md text-sm font-mono transition-colors"
          >
            <UserPlus className="w-4 h-4" />
            ENROLL PERSON
          </button>
        </div>

        {/* Info bar */}
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-3 flex items-start gap-3">
          <Shield className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
          <p className="text-xs text-muted-foreground font-mono leading-relaxed">
            Upload multiple face photos per person for higher accuracy. The AI service uses{" "}
            <span className="text-primary">ArcFace (InsightFace)</span> with cosine similarity
            matching — threshold 0.50. Each enrolled face generates a 512-dimensional embedding
            stored in the database and cached in memory for real-time matching.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Person list */}
          <div className="lg:col-span-1 space-y-2">
            {isLoading ? (
              <div className="space-y-2">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="h-16 bg-card border border-border rounded-lg animate-pulse" />
                ))}
              </div>
            ) : persons.length === 0 ? (
              <div className="bg-card border border-dashed border-border rounded-lg p-8 text-center">
                <UserCheck className="w-8 h-8 text-muted-foreground mx-auto mb-3 opacity-40" />
                <p className="font-mono text-sm text-muted-foreground">No persons enrolled yet</p>
                <p className="font-mono text-xs text-muted-foreground mt-1 opacity-60">
                  Click "Enroll Person" to begin
                </p>
              </div>
            ) : (
              persons.map((person) => (
                <button
                  key={person.id}
                  onClick={() => { setSelectedPersonId(person.id); setEnrollError(""); }}
                  className={`w-full text-left bg-card border rounded-lg p-3 flex items-center gap-3 transition-all ${
                    selectedPersonId === person.id
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/40"
                  }`}
                >
                  {/* Avatar */}
                  <div className="w-10 h-10 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {person.thumbnail_path ? (
                      <img src={person.thumbnail_path} alt={person.name} className="w-full h-full object-cover" />
                    ) : (
                      <UserCheck className="w-5 h-5 text-primary" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-sm font-semibold text-foreground truncate">{person.name}</p>
                    <p className="font-mono text-[10px] text-muted-foreground">
                      {person.face_count} face sample{person.face_count !== 1 ? "s" : ""}
                    </p>
                  </div>
                  {person.face_count > 0 && (
                    <div className="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0" title="Active" />
                  )}
                </button>
              ))
            )}
          </div>

          {/* Person detail / enrollment */}
          <div className="lg:col-span-2">
            {selectedPerson ? (
              <PersonDetail
                person={selectedPerson}
                onDelete={() => {
                  deleteMutation.mutate({ id: selectedPerson.id });
                  setSelectedPersonId(null);
                }}
                onEnrolled={invalidate}
                enrollError={enrollError}
                setEnrollError={setEnrollError}
              />
            ) : (
              <div className="bg-card border border-dashed border-border rounded-lg h-64 flex items-center justify-center">
                <div className="text-center">
                  <Camera className="w-8 h-8 text-muted-foreground mx-auto mb-3 opacity-30" />
                  <p className="font-mono text-sm text-muted-foreground">Select a person to manage their face samples</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add person modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-lg p-6 w-full max-w-sm shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-mono font-bold text-sm text-foreground">ENROLL NEW PERSON</h2>
              <button onClick={() => setShowAdd(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block font-mono text-xs text-muted-foreground mb-1.5 uppercase tracking-wider">Full Name *</label>
                <input
                  autoFocus
                  type="text"
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  placeholder="e.g. Jane Smith"
                  className="w-full bg-background border border-input rounded-md px-3 py-2 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-primary"
                  required
                />
              </div>
              <div>
                <label className="block font-mono text-xs text-muted-foreground mb-1.5 uppercase tracking-wider">Notes</label>
                <input
                  type="text"
                  value={newNotes}
                  onChange={e => setNewNotes(e.target.value)}
                  placeholder="e.g. Employee, Building A"
                  className="w-full bg-background border border-input rounded-md px-3 py-2 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
              <div className="flex gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAdd(false)}
                  className="flex-1 border border-border rounded-md py-2 text-sm font-mono text-muted-foreground hover:text-foreground transition-colors"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  disabled={!newName.trim() || createMutation.isPending}
                  className="flex-1 bg-primary hover:bg-primary/90 disabled:opacity-50 text-primary-foreground rounded-md py-2 text-sm font-mono transition-colors"
                >
                  {createMutation.isPending ? "CREATING..." : "CREATE"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}

// ── Person detail panel ───────────────────────────────────────────────────────

function PersonDetail({
  person,
  onDelete,
  onEnrolled,
  enrollError,
  setEnrollError,
}: {
  person: { id: number; name: string; notes?: string | null; face_count: number; created_at: string; faces?: Array<{ id: number; image_path: string; created_at: string }> };
  onDelete: () => void;
  onEnrolled: () => void;
  enrollError: string;
  setEnrollError: (s: string) => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const qc = useQueryClient();
  const enrollMutation = useEnrollFace({
    mutation: {
      onSuccess: () => { onEnrolled(); setEnrollError(""); },
      onError: (err: any) => setEnrollError(err?.message ?? "Enrollment failed — ensure the photo contains a clear, front-facing face"),
    },
  });
  const deleteFaceMutation = useDeletePersonFace({ mutation: { onSuccess: onEnrolled } });

  const [previews, setPreviews] = useState<string[]>([]);

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    setEnrollError("");

    // Show local previews immediately
    const readers = files.map(f => {
      const r = new FileReader();
      r.readAsDataURL(f);
      return new Promise<string>(resolve => { r.onload = () => resolve(r.result as string); });
    });
    Promise.all(readers).then(setPreviews);

    // Upload each file
    files.forEach(file => {
      const form = new FormData();
      form.append("file", file);
      enrollMutation.mutate({ id: person.id, data: form as any });
    });

    if (fileRef.current) fileRef.current.value = "";
  }

  const faces = (person as any).faces ?? [];

  return (
    <div className="bg-card border border-border rounded-lg p-5 space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="font-mono font-bold text-base text-foreground">{person.name}</h2>
          {person.notes && <p className="font-mono text-xs text-muted-foreground mt-0.5">{person.notes}</p>}
          <p className="font-mono text-[10px] text-muted-foreground mt-1">
            Enrolled {new Date(person.created_at).toLocaleDateString()} · {person.face_count} face sample{person.face_count !== 1 ? "s" : ""}
            {person.face_count >= 5 && (
              <span className="text-emerald-500 ml-2">✓ High accuracy</span>
            )}
            {person.face_count > 0 && person.face_count < 5 && (
              <span className="text-amber-500 ml-2">↑ Add more for better accuracy</span>
            )}
          </p>
        </div>
        <button
          onClick={onDelete}
          className="text-muted-foreground hover:text-destructive transition-colors p-1.5 rounded-md hover:bg-destructive/10"
          title="Delete person"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Upload area */}
      <div>
        <input
          ref={fileRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          multiple
          className="hidden"
          onChange={handleFileChange}
        />
        <button
          onClick={() => fileRef.current?.click()}
          disabled={enrollMutation.isPending}
          className="w-full border-2 border-dashed border-border hover:border-primary/50 rounded-lg p-6 flex flex-col items-center gap-2 transition-colors group disabled:opacity-60"
        >
          <Upload className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
          <p className="font-mono text-sm text-muted-foreground group-hover:text-foreground transition-colors">
            {enrollMutation.isPending ? "Processing face embedding..." : "Upload face photos"}
          </p>
          <p className="font-mono text-[10px] text-muted-foreground">
            JPEG / PNG / WebP · Multiple files · Clear front-facing photos
          </p>
        </button>
      </div>

      {/* Accuracy tip */}
      <div className="text-[10px] font-mono text-muted-foreground grid grid-cols-3 gap-2">
        <div className="bg-background border border-border rounded p-2 text-center">
          <div className="text-amber-500 font-bold">1–2 photos</div>
          <div>Basic recognition</div>
        </div>
        <div className="bg-background border border-border rounded p-2 text-center">
          <div className="text-blue-400 font-bold">3–5 photos</div>
          <div>Good accuracy</div>
        </div>
        <div className="bg-background border border-border rounded p-2 text-center">
          <div className="text-emerald-500 font-bold">5+ photos</div>
          <div>High accuracy</div>
        </div>
      </div>

      {/* Error */}
      {enrollError && (
        <div className="bg-destructive/10 border border-destructive/30 rounded-md p-3 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" />
          <p className="font-mono text-xs text-destructive">{enrollError}</p>
        </div>
      )}

      {/* Face samples grid */}
      {faces.length > 0 && (
        <div>
          <p className="font-mono text-xs text-muted-foreground mb-2 uppercase tracking-wider">
            Enrolled Samples ({faces.length})
          </p>
          <div className="grid grid-cols-5 gap-2">
            {faces.map((face: any) => (
              <div key={face.id} className="relative group aspect-square rounded-md overflow-hidden border border-border bg-background">
                {face.image_path ? (
                  <img
                    src={face.image_path}
                    alt="Face sample"
                    className="w-full h-full object-cover"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Image className="w-5 h-5 text-muted-foreground opacity-40" />
                  </div>
                )}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <button
                    onClick={() => deleteFaceMutation.mutate({ id: person.id, faceId: face.id })}
                    className="text-white hover:text-red-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
