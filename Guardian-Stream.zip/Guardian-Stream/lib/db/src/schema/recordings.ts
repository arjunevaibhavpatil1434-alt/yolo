import { pgTable, serial, text, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const recordingsTable = pgTable("recordings", {
  id: serial("id").primaryKey(),
  camera_id: integer("camera_id").notNull(),
  file_path: text("file_path").notNull(),
  duration_seconds: integer("duration_seconds").notNull().default(0),
  file_size_mb: real("file_size_mb").notNull().default(0),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertRecordingSchema = createInsertSchema(recordingsTable).omit({ id: true });
export type InsertRecording = z.infer<typeof insertRecordingSchema>;
export type Recording = typeof recordingsTable.$inferSelect;
