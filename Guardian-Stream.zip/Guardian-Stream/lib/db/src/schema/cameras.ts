import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const camerasTable = pgTable("cameras", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rtsp_url: text("rtsp_url").notNull(),
  location: text("location").notNull().default(""),
  status: text("status").notNull().default("offline"),
  stream_url: text("stream_url"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const insertCameraSchema = createInsertSchema(camerasTable).omit({ id: true, created_at: true });
export type InsertCamera = z.infer<typeof insertCameraSchema>;
export type Camera = typeof camerasTable.$inferSelect;
