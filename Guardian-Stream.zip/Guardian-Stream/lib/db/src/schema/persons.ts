import { pgTable, serial, text, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const knownPersonsTable = pgTable("known_persons", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  notes: text("notes").default(""),
  face_count: integer("face_count").notNull().default(0),
  thumbnail_path: text("thumbnail_path"),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
});

export const personFacesTable = pgTable("person_faces", {
  id: serial("id").primaryKey(),
  person_id: integer("person_id").notNull(),
  image_path: text("image_path").notNull(),
  // 512-dim ArcFace embedding stored as JSON array
  embedding: jsonb("embedding"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const insertKnownPersonSchema = createInsertSchema(knownPersonsTable).omit({
  id: true, created_at: true, updated_at: true, face_count: true,
});
export const insertPersonFaceSchema = createInsertSchema(personFacesTable).omit({
  id: true, created_at: true,
});

export type KnownPerson = typeof knownPersonsTable.$inferSelect;
export type PersonFace = typeof personFacesTable.$inferSelect;
export type InsertKnownPerson = z.infer<typeof insertKnownPersonSchema>;
export type InsertPersonFace = z.infer<typeof insertPersonFaceSchema>;
